package com.example.cleanup.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.example.cleanup.R;

public class Welcome2 extends Fragment {



    public Welcome2() {
        // Required empty public constructor
    }

    public static Welcome2 newInstance() {

        return new Welcome2();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v=  inflater.inflate(R.layout.fragment_welcome2, container, false);

        return v;
    }
}