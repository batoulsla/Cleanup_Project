package com.example.cleanup.Fragments;

import static com.example.cleanup.Utilities.Config.IP;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.Adapters.CleanerBookingAdapter;
import com.example.cleanup.Interface.FragmentRefresh;
import com.example.cleanup.Models.BookingModel;
import com.example.cleanup.Models.ServiceModel;
import com.example.cleanup.R;
import com.example.cleanup.UI.LogIn;
import com.example.cleanup.Utilities.LoadingLayout;
import com.example.cleanup.Utilities.UserData;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class FragmentBookingCleaner extends Fragment implements FragmentRefresh {

    private TextView text_login,text_no_book;
    private RelativeLayout layout_login;
    private UserData userData;

    private RecyclerView recyclerView;

    private ArrayList<BookingModel> arrayList;

    private CleanerBookingAdapter adapter;

    public FragmentBookingCleaner() {
    }


    public static FragmentBookingCleaner newInstance() {
        return new FragmentBookingCleaner();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v =  inflater.inflate(R.layout.fragment_booking_cleaner, container, false);
        setInitialize(v);
        setActions(v);

        return v;
    }

    private void setInitialize(View v){
        text_login = v.findViewById(R.id.text_login);
        layout_login = v.findViewById(R.id.layout_login);
        text_no_book = v.findViewById(R.id.text_no_book);
        recyclerView = v.findViewById(R.id.recyclerView);
    }

    private void setActions(View v){
        text_login.setOnClickListener(v1 -> {
            Intent intent = new Intent(getActivity(), LogIn.class);
            startActivity(intent);
        });
        if(getActivity() != null){
            userData = new UserData(getActivity());
            if(userData.isLogin()){
                layout_login.setVisibility(View.GONE);
                getBooking();
            }
        }

    }



    public void getBooking(){


       arrayList = new ArrayList<>();
        @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_cleaner_booking.php?cleaner_id="+ userData.getId(), response -> {
            int i = 0;
            try {
                JSONObject jsonObject = new JSONObject(response);
                JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                if(jsonArray.length() == 0){
                    text_no_book.setVisibility(View.VISIBLE);
                    text_no_book.setText("You didn't receive any booking request");
                }else {
                    text_no_book.setVisibility(View.GONE);
                }

                while (i < jsonArray.length()) {
                    JSONObject jSONObject = jsonArray.getJSONObject(i);
                    String bookingTime = jSONObject.getString("bookingTime");
                    String bookingDate = jSONObject.getString("bookingDate");
                    String id_book = jSONObject.getString("bookingID");
                    String book_status = jSONObject.getString("book_status");
                    String rejected_cause = jSONObject.getString("rejected_cause");

                    String cleaner_id = jSONObject.getString("user_id");
                    String customer_email = "", customer_id="", customer_name="", customer_icon="";

                    if(!jSONObject.isNull("customer_info")) {

                         customer_email = jSONObject.getJSONObject("customer_info").getString("email");
                         customer_name = jSONObject.getJSONObject("customer_info").getString("f_name") + " " + jSONObject.getJSONObject("customer_info").getString("l_name");
                         customer_id = jSONObject.getJSONObject("customer_info").getString("user_id");
                         customer_icon = jSONObject.getJSONObject("customer_info").getString("icon");
                    }
                    String site_id = "", site_location = "", site_area="";
                    if(!jSONObject.isNull("site_info")) {
                        site_id = jSONObject.getJSONObject("site_info").getString("site_id");
                        site_location = jSONObject.getJSONObject("site_info").getString("site_location");
                        site_area = jSONObject.getJSONObject("site_info").getString("site_area");
                    }

                    String offer_id="", offer_price="",offer_time="",offer_description="",offer_icon="";
                    if(!jSONObject.isNull("offer_info")){
                        offer_id = jSONObject.getJSONObject("offer_info").getString("offer_id");
                        offer_description = jSONObject.getJSONObject("offer_info").getString("description");
                        offer_price = jSONObject.getJSONObject("offer_info").getString("price");
                        offer_time = jSONObject.getJSONObject("offer_info").getString("time");
                        offer_icon = jSONObject.getJSONObject("offer_info").getString("icon");
                    }


                    String payment_id = "", payemnt_type = "", payment_amount = "";
                    if(!jSONObject.isNull("payment_info")) {
                        payment_id = jSONObject.getJSONObject("payment_info").getString("PaymentID");
                        payemnt_type = jSONObject.getJSONObject("payment_info").getString("PaymentMethod");
                        payment_amount = jSONObject.getJSONObject("payment_info").getString("AmountPaid");
                    }

                    ArrayList<ServiceModel> arrayService = new ArrayList<>();
                    if(!jSONObject.getJSONArray("services").isNull(0)) {
                        int j =0;
                        JSONArray jsonArrayServices = new JSONArray(jSONObject.getString("services"));

                        while (j < jsonArrayServices.length()) {
                            JSONObject jb = jsonArrayServices.getJSONObject(j);
                            String id =  jb.getString("ServiceID");
                            String name =  jb.getString("ServiceName");
                            String price =  jb.getString("ServicePrice");
                            String s_cleaner_id =  jb.getString("s_cleaner_id");
                            arrayService.add(new ServiceModel(id, name, price,s_cleaner_id));
                            j++;
                        }
                    }


                    arrayList.add(new BookingModel(id_book,bookingDate,bookingTime,customer_id, customer_name, customer_email,customer_icon,
                            cleaner_id, "", "", "",book_status, offer_id, offer_price,
                            offer_time, offer_description, offer_icon, site_id, site_location, site_area, payment_id,payemnt_type,payment_amount,rejected_cause,arrayService));
                    i++;
                }

                adapter = new CleanerBookingAdapter(getActivity(), arrayList, this);
                recyclerView.setAdapter(adapter);




            }catch (Exception | Error ignored){


            }


        }, error -> {

        });
        if(getActivity() != null){
            RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
            requestQueue.add(stringRequest);
        }

    }

    @Override
    public void refreshBookingCleaner() {
        getBooking();
    }

    @Override
    public void refreshProfile() {

    }

    @Override
    public void refreshBookingCustomer() {

    }
}