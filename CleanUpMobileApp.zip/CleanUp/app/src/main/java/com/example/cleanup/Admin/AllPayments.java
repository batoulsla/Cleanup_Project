package com.example.cleanup.Admin;

import static com.example.cleanup.Utilities.Config.IPADMIN;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.Adapters.AdminPaymentsAdapter;
import com.example.cleanup.Models.PaymentsModel;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.google.android.material.appbar.MaterialToolbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class AllPayments extends AppCompatClass {
    private RecyclerView recyclerView;
    private AdminPaymentsAdapter adapter;

    private ArrayList<PaymentsModel> arrayList;
    private SearchView searchView;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_common);
        setMethods("Payments","");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        recyclerView = findViewById(R.id.recyclerView);
        toolbar = findViewById(R.id.generalToolbar);


    }

    @Override
    public void setActions() {
        super.setActions();
        toolbar.inflateMenu(R.menu.menu_search);
        MenuItem item = toolbar.getMenu().findItem(R.id.item_search);
        searchView = (SearchView) item.getActionView();
        getPayments();

    }
    public void getPayments(){
        arrayList = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IPADMIN + "select_payments.php", response -> {

            {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        String customer_id = jSONObject.getJSONObject("customer_info").getString("user_id");
                        String f_name = jSONObject.getJSONObject("customer_info").getString("f_name");
                        String l_name = jSONObject.getJSONObject("customer_info").getString("l_name");
                        String customer_icon = jSONObject.getJSONObject("customer_info").getString("icon");
                        String customer_name = f_name +" "+ l_name;

                        String cleaner_id = jSONObject.getJSONObject("cleaner_info").getString("user_id");
                        String f_name_cleaner = jSONObject.getJSONObject("cleaner_info").getString("f_name");
                        String l_name_cleaner = jSONObject.getJSONObject("cleaner_info").getString("l_name");
                        String icon_cleaner = jSONObject.getJSONObject("cleaner_info").getString("icon");
                        String role = jSONObject.getJSONObject("cleaner_info").getString("UserRole");
                        String cleaner_name;
                        if(role.toLowerCase(Locale.ROOT).equals("company")){
                            cleaner_name = f_name_cleaner;
                        }else {
                            cleaner_name = f_name_cleaner +" "+ l_name_cleaner;
                        }

                        String payment_id = ""+jSONObject.getString("PaymentID");
                        String date = ""+jSONObject.getString("PaymentDate");
                        String amount = ""+jSONObject.getString("AmountPaid");
                        String payment_method = jSONObject.getString("PaymentMethod");

                        arrayList.add(new PaymentsModel(payment_id,customer_id, customer_name, customer_icon, cleaner_id, cleaner_name,icon_cleaner, role,amount,date,payment_method));
                        i++;
                    }

                    adapter = new AdminPaymentsAdapter(AllPayments.this, arrayList);
                    recyclerView.setAdapter(adapter);
                    searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                        @Override
                        public boolean onQueryTextSubmit(String query) {
                            return false;
                        }

                        @Override
                        public boolean onQueryTextChange(String newText) {
                            adapter.getFilter().filter(newText);
                            return true;
                        }
                    });
                }catch (Exception | Error ignored){

                }
            }

        }, error -> Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()){ };

        RequestQueue requestQueue = Volley.newRequestQueue(AllPayments.this);
        requestQueue.add(stringRequest);
    }
}