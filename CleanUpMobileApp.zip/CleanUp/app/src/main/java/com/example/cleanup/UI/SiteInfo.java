package com.example.cleanup.UI;

import static com.example.cleanup.Utilities.Config.IP;
import static com.example.cleanup.Utilities.Config.USER_IMAGES_DIR;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.example.cleanup.Utilities.SuperScript;
import com.google.android.material.imageview.ShapeableImageView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public class SiteInfo extends AppCompatClass {
    private TextView location, area, room, floor, name, role;
    private ShapeableImageView icon, icon_call, icon_email;
    private String site_id = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_site_info);
        setMethods("Site information", "");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        role = findViewById(R.id.text_role);
        location = findViewById(R.id.location);
        area = findViewById(R.id.area);
        room = findViewById(R.id.room);
        floor = findViewById(R.id.floor);
        name = findViewById(R.id.text_name);
        icon = findViewById(R.id.icon);
        icon_email = findViewById(R.id.icon_mail);
        icon_call = findViewById(R.id.icon_call);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null){
            site_id = bundle.getString("site_id","");
        }

    }


    @Override
    public void setActions() {
        super.setActions();
        getSiteInfo();
    }
    
    private void getSiteInfo(){
        @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_site_info.php?site_id=" + site_id, response -> {

            {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        String site_location = jSONObject.getString("site_location");
                        String site_area = jSONObject.getString("site_area");
                        String floors_nb = jSONObject.getString("floors_nb");
                        String room_nb = jSONObject.getString("room_nb");
                        String f_name = jSONObject.getString("f_name");
                        String l_name = jSONObject.getString("l_name");
                        String icon = jSONObject.getString("icon");
                        String role = jSONObject.getString("UserRole");
                        String phone = jSONObject.getString("phone_nb");
                        String email = jSONObject.getString("email");
                        this.name.setText(f_name + " " + l_name);
                        this.role.setText(role.toUpperCase(Locale.ROOT));
                        Glide.with(this).load(USER_IMAGES_DIR + icon)
                                .skipMemoryCache(true)
                                .error(R.drawable.ic_user)
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .into(this.icon);
                        this.location.setText(site_location);
                        this.area.setText(site_area + " m" + SuperScript.convert("2"));
                        this.room.setText(room_nb);
                        this.floor.setText(floors_nb);
                        icon_call.setOnClickListener(view -> {
                            Intent intent=new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:"+phone+""));
                            startActivity(intent);
                        });

                        icon_email.setOnClickListener(v -> {
                            Intent intent = new Intent(Intent.ACTION_SENDTO);
                            intent.setData(Uri.parse("mailto:"+email));
                            intent.putExtra(Intent.EXTRA_EMAIL, email);
                            intent.putExtra(Intent.EXTRA_SUBJECT, "");
                            startActivity(intent);

                        });
                        i++;
                    }


                }catch (Exception | Error ignored){

                }
            }

        }, error -> Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()){ };

        RequestQueue requestQueue = Volley.newRequestQueue(SiteInfo.this);
        requestQueue.add(stringRequest);
    }
}