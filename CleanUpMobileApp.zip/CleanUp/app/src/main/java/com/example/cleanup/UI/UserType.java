package com.example.cleanup.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

public class UserType extends AppCompatClass {
    private MaterialButton btn_cleaner_individual, btn_cleaner_company, btn_customer;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_type);
        setMethods("","");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        btn_cleaner_company = findViewById(R.id.btn_cleaner_company);
        btn_cleaner_individual = findViewById(R.id.btn_cleaner_individual);
        btn_customer = findViewById(R.id.btn_customer);
        toolbar = findViewById(R.id.generalToolbar);
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    public void setActions() {
        super.setActions();
        btn_cleaner_company.setOnClickListener(v -> openLogin("company"));
        btn_cleaner_individual.setOnClickListener(v -> openLogin("individual"));
        btn_customer.setOnClickListener(v -> openLogin("customer"));
        toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_close));
    }

    private void openLogin(String type){
        Intent intent = new Intent(UserType.this, SignUp.class);
        intent.putExtra("type", type);
        startActivity(intent);
    }
}