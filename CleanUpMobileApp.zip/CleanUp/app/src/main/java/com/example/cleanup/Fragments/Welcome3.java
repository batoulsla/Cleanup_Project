package com.example.cleanup.Fragments;

import static android.content.Context.MODE_PRIVATE;
import static com.example.cleanup.Utilities.Config.IP;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.Interface.FragmentRefresh;
import com.example.cleanup.R;
import com.example.cleanup.UI.MainActivity;
import com.example.cleanup.UI.UserType;
import com.example.cleanup.Utilities.LoadingLayout;
import com.example.cleanup.Utilities.UserData;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;
import java.util.Map;

public class Welcome3 extends Fragment {

    private MaterialToolbar toolbar;
    FragmentRefresh fragmentRefresh;
    TextView text_continue;

    private UserData userData;
    private TextView text_sign_up;
    private SharedPreferences.Editor editor;
    private MaterialButton btn_login;
    private TextInputEditText email, password;

    public Welcome3() {
        // Required empty public constructor
    }

    public static Welcome3 newInstance() {

        return new Welcome3();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v=  inflater.inflate(R.layout.fragment_welcome3, container, false);
        setInitialize(v);
        setActions();
        return v;
    }

    public void setInitialize(View v) {
        editor = getActivity().getSharedPreferences("firstTime", MODE_PRIVATE).edit();
        text_continue = v.findViewById(R.id.text_continue);
        toolbar = v.findViewById(R.id.generalToolbar);
        text_sign_up = v.findViewById(R.id.text_sign_up);
        btn_login = v.findViewById(R.id.btn_login);
        email = v.findViewById(R.id.email_edit);
        password = v.findViewById(R.id.password_edit);
    }


    @SuppressLint("UseCompatLoadingForDrawables")
 
    public void setActions() {
        text_continue.setOnClickListener(v -> {
            editor.putBoolean("firstTime",false);
            editor.apply();
            Intent intent = new Intent(getActivity(), MainActivity.class);
            startActivity(intent);
        });
        toolbar.setVisibility(View.GONE);
        text_sign_up.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), UserType.class);
            startActivity(intent);
        });
        btn_login.setOnClickListener(v -> login());
    }

    private void login(){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, IP + "login.php", response -> {
            if(!response.trim().contains(",,")){
                Toast.makeText(getActivity(), response.trim(), Toast.LENGTH_SHORT).show();
            }else{
                editor.putBoolean("firstTime",false);
                editor.apply();
                if(getActivity() != null){
                    LoadingLayout.show(getActivity());
                }

                userData = new UserData(getActivity());
                Toast.makeText(getActivity(), "Success", Toast.LENGTH_SHORT).show();
                String [] data = response.trim().split(",,");
                userData.setUserData(data[0], data[1]);
                Intent intent = new Intent(getActivity(), MainActivity.class);
                intent.putExtra("tab","4");
                LoadingLayout.hide(getActivity());
                startActivity(intent);
                getActivity().finish();
            }
        }, error -> {
            Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();

        }){

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("email",email.getText().toString());
                map.put("password",password.getText().toString());
                return map;
            }
        };
        if(getActivity() != null){
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);}
    }

}