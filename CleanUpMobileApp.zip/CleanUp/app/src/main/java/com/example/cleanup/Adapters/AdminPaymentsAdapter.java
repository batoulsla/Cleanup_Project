package com.example.cleanup.Adapters;

import static com.example.cleanup.Utilities.Config.USER_IMAGES_DIR;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.cleanup.Models.PaymentsModel;
import com.example.cleanup.Models.UsersModel;
import com.example.cleanup.R;
import com.example.cleanup.UI.UserProfile;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdminPaymentsAdapter extends RecyclerView.Adapter<AdminPaymentsAdapter.recyclerHolder> implements Filterable {
    ArrayList<PaymentsModel> list; // List to store the payments data
    ArrayList<PaymentsModel> listFull;// A copy of the full payments data (used for filtering)
    Activity activity;// Reference to the activity using this adapter

    public AdminPaymentsAdapter(Activity activity, ArrayList<PaymentsModel> list) {
        this.list = list;
        this.activity = activity;
        listFull =new ArrayList<>(list); // Create a copy of the full list
    }
    // ViewHolder class for holding views of each item in the RecyclerView
    public static class recyclerHolder extends RecyclerView.ViewHolder {
        public TextView customer_name, cleaner_name, amount, date, payment_method;
        private final ShapeableImageView icon_customer, icon_cleaner;
        private final LinearLayoutCompat layout_customer, layout_cleaner;

        public recyclerHolder(View v) {
            super(v);

            customer_name = v.findViewById(R.id.customer_name); // Reference to customer name TextView
            cleaner_name = v.findViewById(R.id.cleaner_name); // Reference to cleaner name TextView
            amount = v.findViewById(R.id.amount); // Reference to amount TextView
            date = v.findViewById(R.id.date); // Reference to date TextView
            payment_method = v.findViewById(R.id.payment_method); // Reference to payment method TextView
            layout_customer = v.findViewById(R.id.layout_customer); // Reference to customer layout LinearLayout
            layout_cleaner = v.findViewById(R.id.layout_cleaner); // Reference to cleaner layout LinearLayout
            icon_customer = v.findViewById(R.id.icon_customer); // Reference to customer icon ImageView
            icon_cleaner = v.findViewById(R.id.icon_cleaner); // Reference to cleaner icon ImageView
        }
    }

    @NonNull
    @Override
    public recyclerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item in the RecyclerView
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_admin_payments, parent, false);
        return new recyclerHolder(v);
    }

    @SuppressLint({"SetTextI18n", "ResourceType", "NotifyDataSetChanged"})
    @Override
    public void onBindViewHolder(@NonNull final recyclerHolder holder, @SuppressLint("RecyclerView") final int position) {// Get the current payment item
        PaymentsModel currentItem = list.get(position);
        // Set the data for each view in the ViewHolder
        holder.customer_name.setText(currentItem.getCustomer_name());
        holder.cleaner_name.setText(currentItem.getCleaner_name());
        holder.date.setText(currentItem.getDate());
        holder.amount.setText("USD "+currentItem.getAmount());
        holder.payment_method.setText(currentItem.getPayment_method().toUpperCase(Locale.ROOT));
        // Load the customer icon image using Glide library
        Glide.with(activity).load(USER_IMAGES_DIR + list.get(position).getCustomer_icon())
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .error(R.drawable.ic_user)
                .into(holder.icon_customer);
        // Load the cleaner icon image using Glide library
        Glide.with(activity).load(USER_IMAGES_DIR + list.get(position).getCleaner_icon())
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .error(R.drawable.ic_user)
                .into(holder.icon_cleaner);
// Set click listeners for the customer and cleaner layouts
        holder.layout_cleaner.setOnClickListener(v -> {
            // Open UserProfile activity for the cleaner when clicked
            Intent intent = new Intent(activity, UserProfile.class);
            intent.putExtra("user_id", list.get(position).getCleaner_id());
            activity.startActivity(intent);
        });
        holder.layout_customer.setOnClickListener(v -> {
            // Open UserProfile activity for the customer when clicked
            Intent intent = new Intent(activity, UserProfile.class);
            intent.putExtra("user_id", list.get(position).getCustomer_id());
            activity.startActivity(intent);
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    } // Return the number of items in the list
    @Override
    public Filter getFilter() {
        return filter;
    }// Return the filter object for filtering the data
    // filter android widgets
    private final Filter filter =new Filter() {
        @Override
        // Filter for filtering the payments data based on search query

        protected FilterResults performFiltering(CharSequence charSequence) {
            List<PaymentsModel> filteredList=new ArrayList<>();
            if(charSequence==null || charSequence.length()==0){
                filteredList.addAll(listFull);// If the search query is empty, return the full list
            }
            else {
                String filterPattern=charSequence.toString().toLowerCase().trim();
                for (PaymentsModel item: listFull){   // Check if any field in the payment item matches the search query
                    if(item.getCleaner_name().toLowerCase().contains(filterPattern)|
                            item.getCustomer_name().toLowerCase().contains(filterPattern)|
                            item.getDate().toLowerCase().contains(filterPattern)|
                            item.getCleaner_role().toLowerCase().contains(filterPattern)|
                            item.getPayment_method().toLowerCase().contains(filterPattern)|
                            item.getAmount().toLowerCase().contains(filterPattern) ){
                        filteredList.add(item); // Add the matching item to the filtered list
                    }
                }
            }
            FilterResults results=new FilterResults();
            results.values=filteredList;
            return results;
        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        @SuppressWarnings("unchecked")
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            try {
                list.clear();
                list.addAll((ArrayList<PaymentsModel>)filterResults.values);
                notifyDataSetChanged(); // Update the RecyclerView with the filtered list
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };

}