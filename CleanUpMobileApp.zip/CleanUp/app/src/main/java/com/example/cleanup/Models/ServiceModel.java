package com.example.cleanup.Models;

import com.android.volley.toolbox.StringRequest;

public class ServiceModel {
    String id, name, price, cleaner_id;

    public ServiceModel(String id, String name, String price, String cleaner_id) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.cleaner_id = cleaner_id;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getCleaner_id() {
        return cleaner_id;
    }
}
