package com.example.cleanup.Adapters;

import static com.example.cleanup.Utilities.Config.USER_IMAGES_DIR;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cleanup.Models.CleanersModel;
import com.example.cleanup.R;
import com.example.cleanup.UI.Booking;
import com.example.cleanup.UI.UserProfile;
import com.example.cleanup.Utilities.UserData;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CleanersAdapter extends RecyclerView.Adapter<CleanersAdapter.MyHolder> implements Filterable {
    private final ArrayList<CleanersModel> list;
    private final ArrayList<CleanersModel> listFull;
    private final Context context;
    private final String site_id ;
    private UserData userData;

    public CleanersAdapter(Context activity, ArrayList<CleanersModel> list, String site_id) {
        this.list = list;
        this.site_id = site_id;
        context = activity;
        listFull =new ArrayList<>(list);
        userData = new UserData(context);
    }

    public static class MyHolder extends RecyclerView.ViewHolder {
        private final TextView name;
        private final TextView role;
        private final TextView employee_nb;
        private final TextView address;
        private final MaterialCardView cardView;
        private final ShapeableImageView icon, icon_book, icon_eco;

        public MyHolder(View v) {
            super(v);
            icon_eco = v.findViewById(R.id.icon_eco);
            name = v.findViewById(R.id.name);
            role = v.findViewById(R.id.role);
            employee_nb = v.findViewById(R.id.employee_nb);
            icon = v.findViewById(R.id.icon);
            address = v.findViewById(R.id.address);
            cardView = v.findViewById(R.id.cardView);
            icon_book = v.findViewById(R.id.icon_book);


        }
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_company, parent, false);
        return new MyHolder(v);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final MyHolder holder, @SuppressLint("RecyclerView") final int position) {
        CleanersModel currentItem = list.get(position);
        holder.role.setText(currentItem.getRole().toUpperCase(Locale.ROOT));
        if(userData.getId().equals("")){
            holder.icon_book.setVisibility(View.GONE);
        }else{
            if(userData.getRole().equals("customer")){
                holder.icon_book.setVisibility(View.VISIBLE);
            }else{
                holder.icon_book.setVisibility(View.GONE);
            }
        }
        if(currentItem.getRole().toLowerCase(Locale.ROOT).equals("company")){
            holder.employee_nb.setText(currentItem.getEmployee_nb() + " employees");
            holder.employee_nb.setVisibility(View.VISIBLE);
            holder.name.setText(currentItem.getFname() );
        }else{
            holder.employee_nb.setVisibility(View.GONE);
            holder.name.setText(currentItem.getFname() + " " + currentItem.getLname());
        }

        if(!currentItem.getAddress().trim().equals("")){

            holder.address.setText(currentItem.getAddress());

            holder.address.setVisibility(View.VISIBLE);
        }else {
            holder.address.setVisibility(View.GONE);
        }
        Glide.with(context).load(USER_IMAGES_DIR +
                        currentItem.getIcon())
                .error(R.drawable.ic_user)
                .into(holder.icon);

        holder.cardView.setOnClickListener(v -> {
            Intent intent = new Intent(context, UserProfile.class);
            intent.putExtra("site_id", site_id);
            intent.putExtra("user_id", list.get(position).getCleaner_id());
            intent.putExtra("offer_id", "");
            intent.putExtra("type", "service");
            context.startActivity(intent);
        });

        holder.icon_book.setOnClickListener(v -> {
            Intent intent = new Intent(context, Booking.class);
            intent.putExtra("site_id", site_id);
            intent.putExtra("cleaner_id", list.get(position).getCleaner_id());
            intent.putExtra("offer_id", "");
            intent.putExtra("type", "service");
            intent.putExtra("amount", 0.0);
            context.startActivity(intent);
        });

        switch (currentItem.getScore()) {
            case "a":
                holder.icon_eco.setVisibility(View.VISIBLE);
                Glide.with(context).load(R.drawable.ic_a).into(holder.icon_eco);
                break;
            case "c":
                holder.icon_eco.setVisibility(View.VISIBLE);
                Glide.with(context).load(R.drawable.ic_c).into(holder.icon_eco);
                break;
            case "b":
                holder.icon_eco.setVisibility(View.VISIBLE);
                Glide.with(context).load(R.drawable.ic_b).into(holder.icon_eco);
                break;
            default:
                holder.icon_eco.setVisibility(View.GONE);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }



    @Override
    public Filter getFilter() {
        return filter;
    }
    // filter android widgets
    private final Filter filter =new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<CleanersModel> list1=new ArrayList<>();
            if(charSequence==null || charSequence.length()==0){
                list1.addAll(listFull);
            }
            else {
                String filterPattern=charSequence.toString().toLowerCase().trim();
                for (CleanersModel item: listFull){
                    if(
                            item.getAddress().toLowerCase().contains(filterPattern)|
                                    item.getFname().toLowerCase().contains(filterPattern)|
                                    item.getLname().toLowerCase().contains(filterPattern)|
                                    item.getRole().toLowerCase().contains(filterPattern) ){
                        list1.add(item);
                    }
                }
            }
            FilterResults results=new FilterResults();
            results.values=list1;
            return results;
        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        @SuppressWarnings("unchecked")
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            try {
                list.clear();
                list.addAll((ArrayList<CleanersModel>)filterResults.values);
                notifyDataSetChanged();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };
}