package com.example.cleanup.UI;

import static com.example.cleanup.Utilities.Config.IP;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.Adapters.CleanerOfferAdapter;
import com.example.cleanup.Models.OffersModel;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.example.cleanup.Utilities.UserData;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class CleanerOffers extends AppCompatClass {
    private RecyclerView recyclerView;

    private ArrayList<OffersModel> arrayList;
    private TextView btn_add;

    private UserData userData;

    private CleanerOfferAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cleaner_offers);
        setMethods("Offers", "");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        btn_add = findViewById(R.id.btn_add_offer);
        recyclerView = findViewById(R.id.recyclerView);
        userData = new UserData(CleanerOffers.this);

    }

    @Override
    public void setActions() {
        super.setActions();
        btn_add.setOnClickListener(v -> {
            Intent intent = new Intent(CleanerOffers.this, AddOffer.class);
            startActivity(intent);
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        getOffers();
    }

    public void getOffers(){
        arrayList = new ArrayList<>();
            @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_offers_where.php?user_id="+ userData.getId(), response -> {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    if(jsonArray.length() == 0){
                        Toast.makeText(CleanerOffers.this,   "There are no offers", Toast.LENGTH_SHORT).show();
                    }

                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        String description = jSONObject.getString("description");
                        String date = jSONObject.getString("time");
                        String price = jSONObject.getString("price");
                        String icon = jSONObject.getString("icon");
                        String id_offer = jSONObject.getString("offer_id");
                        String used = jSONObject.getString("used");
                        arrayList.add(new OffersModel(id_offer, icon,description,date,price,userData.getId(), used));
                        i++;
                    }
                    adapter = new CleanerOfferAdapter(CleanerOffers.this, arrayList);
                    recyclerView.setAdapter(adapter);
                }catch (Exception | Error ignored){

                }

            }, error -> {

            });
            RequestQueue requestQueue = Volley.newRequestQueue(CleanerOffers.this);
            requestQueue.add(stringRequest);
        }



}