package com.example.cleanup.Adapters;

import static com.example.cleanup.Utilities.Config.USER_IMAGES_DIR;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cleanup.Models.CleanersModel;
import com.example.cleanup.R;
import com.example.cleanup.UI.Booking;
import com.example.cleanup.UI.UserProfile;
import com.example.cleanup.Utilities.UserData;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.Locale;

public class AllCleanerAdapter extends RecyclerView.Adapter<AllCleanerAdapter.MyHolder> {
    private final ArrayList<CleanersModel> list;
    private final Context context;

    private UserData userData;

    public AllCleanerAdapter(Context activity, ArrayList<CleanersModel> list) {
        this.list = list;
        context = activity;
        userData = new UserData(context);
    }

    public static class MyHolder extends RecyclerView.ViewHolder {
        private final TextView name;
        private final TextView role;
        private final MaterialCardView cardView;
        private final ShapeableImageView icon, icon_book, icon_eco;

        public MyHolder(View v) {
            super(v);
            name = v.findViewById(R.id.name);
            role = v.findViewById(R.id.role);
            icon = v.findViewById(R.id.icon);
            cardView = v.findViewById(R.id.cardView);

            icon_book = v.findViewById(R.id.icon_book);
            icon_eco = v.findViewById(R.id.icon_eco);


        }
    }

    @NonNull
    @Override
    // Inflate the layout for each item in the list
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_all_cleaners, parent, false);
        return new MyHolder(v);
    }

    @SuppressLint("SetTextI18n")
    @Override
    // Set the role text to uppercase
    public void onBindViewHolder(@NonNull final MyHolder holder, @SuppressLint("RecyclerView") final int position) {
        CleanersModel currentItem = list.get(position);
        holder.role.setText(currentItem.getRole().toUpperCase(Locale.ROOT));
        // Check if the user is logged in and has the role of "customer" to show the booking icon else hide it
        if(userData.getId().equals("")){
            holder.icon_book.setVisibility(View.GONE);
        }else{
            if(userData.getRole().equals("customer")){
                holder.icon_book.setVisibility(View.VISIBLE);
            }else{
                holder.icon_book.setVisibility(View.GONE);
            }
        }
        // Set the name of the cleaner
        if (currentItem.getRole().toLowerCase(Locale.ROOT).equals("company")) {
            holder.name.setText(currentItem.getFname());
        } else {
            holder.name.setText(currentItem.getFname() + " " + currentItem.getLname());
        }

        // Load the cleaner's icon using Glide library

        Glide.with(context).load(USER_IMAGES_DIR +
                        currentItem.getIcon())
                .error(R.drawable.ic_user)
                .into(holder.icon);
        // Set a click listener on the card view to open the user's profile
        holder.cardView.setOnClickListener(v -> {
            Intent intent = new Intent(context, UserProfile.class);
            intent.putExtra("site_id", "");
            intent.putExtra("user_id", list.get(position).getCleaner_id());
            intent.putExtra("offer_id", "");
            intent.putExtra("type", "service");
            context.startActivity(intent);
        });
        // Set a click listener on the booking icon to initiate the booking process
        holder.icon_book.setOnClickListener(v -> {
            Intent intent = new Intent(context, Booking.class);
            intent.putExtra("site_id", "");
            intent.putExtra("cleaner_id", list.get(position).getCleaner_id());
            intent.putExtra("offer_id", "");
            intent.putExtra("type", "service");
            intent.putExtra("amount", 0.0);
            context.startActivity(intent);
        });
        // Show the appropriate eco icon based on the cleaner's score
        switch (currentItem.getScore()) {
            case "a":
                holder.icon_eco.setVisibility(View.VISIBLE);
                Glide.with(context).load(R.drawable.ic_a).into(holder.icon_eco);
                break;
            case "c":
                holder.icon_eco.setVisibility(View.VISIBLE);
                Glide.with(context).load(R.drawable.ic_c).into(holder.icon_eco);
                break;
            case "b":
                holder.icon_eco.setVisibility(View.VISIBLE);
                Glide.with(context).load(R.drawable.ic_b).into(holder.icon_eco);
                break;
            default:
                holder.icon_eco.setVisibility(View.GONE);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


}