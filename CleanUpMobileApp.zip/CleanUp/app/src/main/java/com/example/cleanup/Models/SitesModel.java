package com.example.cleanup.Models;

public class SitesModel {
    String id, area, location, user_id;
    String room_nb, floors_nb, used;

    public SitesModel(String id, String area, String location, String user_id, String room_nb, String floors_nb, String used) {
        this.id = id;
        this.area = area;
        this.location = location;
        this.user_id = user_id;
        this.room_nb = room_nb;
        this.floors_nb = floors_nb;
        this.used = used;
    }

    public String getId() {
        return id;
    }

    public String getArea() {
        return area;
    }

    public String getLocation() {
        return location;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getRoom_nb() {
        return room_nb;
    }

    public String getFloors_nb() {
        return floors_nb;
    }

    public String getUsed() {
        return used;
    }
}
