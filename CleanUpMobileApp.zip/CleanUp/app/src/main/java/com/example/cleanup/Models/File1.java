package com.example.cleanup.Models;

import java.util.ArrayList;

public class File1 {
    ArrayList<UsersModel> arrayList = new ArrayList<>();

    public File1() {

    }
}
