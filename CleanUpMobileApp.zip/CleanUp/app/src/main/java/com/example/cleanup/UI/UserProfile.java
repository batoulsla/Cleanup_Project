package com.example.cleanup.UI;

import static com.example.cleanup.Utilities.Config.IP;
import static com.example.cleanup.Utilities.Config.USER_IMAGES_DIR;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.cleanup.Adapters.BookReviewsAdapter;
import com.example.cleanup.Models.ProductsModel;
import com.example.cleanup.Models.ReviewsModel;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.example.cleanup.Utilities.LoadingLayout;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.imageview.ShapeableImageView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

public class UserProfile extends AppCompatClass {
    private TextView text_name, text_role, text_employee_nb, text_address, text_bio,text_no_reviews;
    private LottieAnimationView btn_offers;
    private ChipGroup chipGroup;
    private  ArrayList<ReviewsModel> arrayList;
    private LinearLayoutCompat layout_reviews;
    RecyclerView recyclerView;
    private BookReviewsAdapter adapter;
    private ArrayList<ProductsModel> products_ids ;
    private ShapeableImageView icon_email, icon_phone, icon, icon_eco;
    private LinearLayoutCompat layout_eco,layout_employee, layout_address,layout_services, layout_bio,layout_cleaner;
    private String user_id = "", site_id="";
    private AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        setMethods("Profile", "");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        text_no_reviews = findViewById(R.id.text_no_reviews);
        layout_reviews = findViewById(R.id.layout_reviews);
        layout_eco = findViewById(R.id.layout_eco);
        icon_eco = findViewById(R.id.icon_eco);
        text_name = findViewById(R.id.text_name);
        icon = findViewById(R.id.icon);
        icon_email = findViewById(R.id.icon_mail);
        icon_phone = findViewById(R.id.icon_call);
        text_role = findViewById(R.id.text_role);
        btn_offers = findViewById(R.id.btn_offers);
        layout_employee = findViewById(R.id.layout_employee);
        layout_cleaner = findViewById(R.id.layout_cleaner);
        text_employee_nb = findViewById(R.id.employee_nb);
        text_address = findViewById(R.id.address);
        chipGroup = findViewById(R.id.chipGroup);
        layout_bio = findViewById(R.id.layout_bio);
        layout_services = findViewById(R.id.layout_services);
        text_bio = findViewById(R.id.bio);
        layout_address = findViewById(R.id.layout_address);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setNestedScrollingEnabled(false);
        products_ids = new ArrayList<>();
        arrayList = new ArrayList<>();
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle !=null){
            user_id = bundle.getString("user_id", "");
            site_id = bundle.getString("site_id", "");
        }
    }


    @Override
    public void setActions() {
        super.setActions();
        getUserData();
        btn_offers.setOnClickListener(v -> {
            Intent intent = new Intent(UserProfile.this, Offers.class);
            intent.putExtra("user_id", user_id);
            intent.putExtra("site_id", site_id);
            startActivity(intent);
        });

    }

    private void getUserData() {
            @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_user.php?id="+ user_id, response -> {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        String email = jSONObject.getString("email");
                        String phone = jSONObject.getString("phone_nb");
                        String prd = jSONObject.getString("products_ids");
                        int offers_count = jSONObject.getInt("offers_count");

                        calculateEco(prd);
                        icon_phone.setOnClickListener(view -> {
                            Intent intent=new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:"+phone+""));
                            startActivity(intent);
                        });

                        icon_email.setOnClickListener(v -> {
                            Intent intent = new Intent(Intent.ACTION_SENDTO);
                            intent.setData(Uri.parse("mailto:"+email));
                            intent.putExtra(Intent.EXTRA_EMAIL, email);
                            intent.putExtra(Intent.EXTRA_SUBJECT, "");
                            startActivity(intent);

                        });


                        text_role.setText(jSONObject.getString("UserRole") );
                        text_address.setText(jSONObject.getString("address") );
                        if(jSONObject.getString("UserRole").toLowerCase(Locale.ROOT).equals("company")){
                            text_name.setText(jSONObject.getString("f_name"));
                            layout_cleaner.setVisibility(View.VISIBLE);
                            layout_employee.setVisibility(View.VISIBLE);
                            text_employee_nb.setText(jSONObject.getString("employee_nb") );
                            text_bio.setText(jSONObject.getString("bio") );
                            if(offers_count == 0){
                                btn_offers.setVisibility(View.GONE);
                            }else {
                                btn_offers.setVisibility(View.VISIBLE);
                            }

                        }else  if(jSONObject.getString("UserRole").toLowerCase(Locale.ROOT).equals("individual")){
                            text_name.setText(jSONObject.getString("f_name") +" "+ jSONObject.getString("l_name"));
                            layout_cleaner.setVisibility(View.VISIBLE);
                            layout_employee.setVisibility(View.GONE);
                            text_bio.setText(jSONObject.getString("bio") );
                            btn_offers.setVisibility(View.GONE);
                        }else{
                            text_name.setText(jSONObject.getString("f_name") +" "+ jSONObject.getString("l_name"));
                            layout_bio.setVisibility(View.GONE);
                            layout_address.setVisibility(View.VISIBLE);
                            layout_employee.setVisibility(View.GONE);
                            layout_reviews.setVisibility(View.GONE);
                            btn_offers.setVisibility(View.GONE);
                            layout_services.setVisibility(View.GONE);
                            layout_eco.setVisibility(View.GONE);
                        }

                            Glide.with(UserProfile.this).load(USER_IMAGES_DIR + jSONObject.getString("icon"))
                                    .skipMemoryCache(true)
                                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                                    .error(R.drawable.ic_user)
                                    .into(icon);


                        i++;
                    }
                    getServices();
                    getReviews();
                }catch (Exception | Error ignored){

                }

            }, error -> {

            });


            RequestQueue requestQueue = Volley.newRequestQueue(UserProfile.this);
            requestQueue.add(stringRequest);
        }


    private void calculateEco(String prd_ids){
        String [] ids = prd_ids.split(",");
            @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_eco.php", response -> {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        String id = jSONObject.getString("p_id");
                        String p_name = jSONObject.getString("p_name");
                        String p_clarification = jSONObject.getString("p_clarification");
                        for(String p_id: ids){
                            if(p_id.equals(id)){
                                products_ids.add(new ProductsModel(id, p_name, p_clarification));
                            }
                        }
                        i++;
                    }
                   if(products_ids.size()>0){
                       String first_item = products_ids.get(0).getClarification();
                       for(int j =0 ;j<products_ids.size();j++){
                           if(first_item.equals("friendly") && first_item.equals(products_ids.get(j).getClarification())){
                               Glide.with(this).load(R.drawable.ic_a).into(icon_eco);
                           }else if(first_item.equals("not friendly") && first_item.equals(products_ids.get(j).getClarification())){
                               Glide.with(this).load(R.drawable.ic_c).into(icon_eco);
                           }else{
                             Glide.with(this).load(R.drawable.ic_b).into(icon_eco);
                           }
                       }
                   }else{
                    icon_eco.setVisibility(View.GONE);

                   }
                    layout_eco.setOnClickListener(v -> {
                        AlertDialog.Builder builder = new AlertDialog.Builder(UserProfile.this);
                        View dialogView = View.inflate(UserProfile.this, R.layout.layout_cleaninng_products, null);
                        TextView btn_ok = dialogView.findViewById(R.id.btn_ok);

                        ChipGroup chipGroupCleaningProducts = dialogView.findViewById(R.id.chipGroupCleaningProducts);
                        for(int j  = 0; j<products_ids.size();j++){
                            final Chip chip=(Chip)View.inflate(UserProfile.this, R.layout.chip_items_read,null);
                            chip.setText(products_ids.get(j).getName());
                            if(products_ids.get(j).getClarification().toLowerCase(Locale.ROOT).equals("friendly")){
                                chip.setChipBackgroundColor(ColorStateList.valueOf(getResources().getColor(R.color.chip_friendly,null)));
                            }else{
                                chip.setChipBackgroundColor(ColorStateList.valueOf(getResources().getColor(R.color.chip_not_friendly,null)));
                            }
                            chipGroupCleaningProducts.addView(chip);
                        }

                        builder.setCancelable(true);
                        btn_ok.setOnClickListener(v12 -> {
                            alertDialog.dismiss();
                        });

                        builder.setView(dialogView);
                        alertDialog = builder.create();
                        if (dialogView.getParent() != null) {
                            ((ViewGroup) dialogView.getParent()).removeView(dialogView);
                        }
                        alertDialog.show();

                    });

                }catch (Exception | Error ignored){
                }

            }, error -> {

            });
            RequestQueue requestQueue = Volley.newRequestQueue(UserProfile.this);
            requestQueue.add(stringRequest);

        }



    private void getServices(){

            @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_services_where.php?user_id="+ user_id, response -> {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        final Chip chip=(Chip)View.inflate(UserProfile.this, R.layout.chip_items_read,null);
                        chip.setText(jSONObject.getString("ServiceName")+" - "+jSONObject.getString("ServicePrice"));
                        chipGroup.addView(chip);
                        i++;
                    }
                }catch (Exception | Error ignored){

                }

            }, error -> {

            });
            RequestQueue requestQueue = Volley.newRequestQueue(UserProfile.this);
            requestQueue.add(stringRequest);

    }

    public void getReviews(){
        arrayList = new ArrayList<>();
        @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_reviews_where_cleaner.php?cleaner_id="+ user_id, response -> {
            int i = 0;

            try {

                JSONObject jsonObject = new JSONObject(response);
                JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                if(jsonArray.length() == 0){
                    text_no_reviews.setVisibility(View.VISIBLE);

                }else {
                    text_no_reviews.setVisibility(View.GONE);
                }

                while (i < jsonArray.length()) {
                    JSONObject jSONObject = jsonArray.getJSONObject(i);
                    String text = jSONObject.getString("ReviewText");
                    String user_id = jSONObject.getString("UserID");
                    String id = jSONObject.getString("ReviewID");
                    String cleaner_id = jSONObject.getString("CleanerID");
                    String book_id = jSONObject.getString("r_booking_id");
                    String customer_name = jSONObject.getString("f_name") +" "+jSONObject.getString("l_name")  ;
                    String customer_icon = jSONObject.getString("icon");
                    String date = jSONObject.getString("date");
                    arrayList.add(new ReviewsModel(id, book_id,user_id,cleaner_id, text,customer_name,customer_icon,date));
                    i++;
                }

                adapter = new BookReviewsAdapter(UserProfile.this, arrayList);
                recyclerView.setAdapter(adapter);

            }catch (Exception | Error ignored){

            }

        }, error -> {

        });
        RequestQueue requestQueue = Volley.newRequestQueue(UserProfile.this);
        requestQueue.add(stringRequest);
    }
}