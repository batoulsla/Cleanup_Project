package com.example.cleanup.Utilities;

public interface MyClass {
    void setInitialize();
    void setActions();
}
