package com.example.cleanup.Models;

public class ProductsModel {
    String id, name, clarification;

    public ProductsModel(String id, String name, String clarification) {
        this.id = id;
        this.name = name;
        this.clarification = clarification;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getClarification() {
        return clarification;
    }
}
