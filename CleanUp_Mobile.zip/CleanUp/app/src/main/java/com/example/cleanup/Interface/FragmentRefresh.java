package com.example.cleanup.Interface;

public interface FragmentRefresh {
     void refreshBookingCleaner();
     void refreshProfile();

     void refreshBookingCustomer();
}
