package com.example.cleanup.Utilities;

import android.content.Context;
import android.content.Intent;

import com.example.cleanup.UI.LogIn;

public class CheckLogin {
    public static void start(Context context, Class<?> activity){
        UserData userData = new UserData(context);
        if(userData.isLogin()){
            Intent intent = new Intent(context, activity);
            context.startActivity(intent);
        }else{
            Intent intent = new Intent(context, LogIn.class);
            context.startActivity(intent);
        }

    }
}
