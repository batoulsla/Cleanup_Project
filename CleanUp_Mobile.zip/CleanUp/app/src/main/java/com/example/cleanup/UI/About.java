package com.example.cleanup.UI;

import android.os.Bundle;

import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;

public class About extends AppCompatClass {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_abouts);
            setMethods(getString(R.string.about_us),"");

    }
}
