package com.example.cleanup.Enumerations;

import androidx.annotation.NonNull;
//Enums in Java are used to represent a fixed set of constants. In this code, an
// enumeration called PaymentMethod is defined. It represents different types of payment methods, such as debit card, PayPal, credit card, and cash.
public enum PaymentMethod {


    DEBIT{
        @NonNull
        @Override
        public String toString() {
            return "debit card";
        }
    },
    PAYPAL{
        @NonNull
        @Override
        public String toString() {
            return "paypal";
        }
    },
    CREDIT{
        @NonNull
        @Override
        public String toString() {
            return "credit card";
        }
    },
    CASH{
        @NonNull
        @Override
        public String toString() {
            return "cash";
        }
    }
}
