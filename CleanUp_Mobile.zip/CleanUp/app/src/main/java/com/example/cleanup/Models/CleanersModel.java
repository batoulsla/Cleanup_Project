package com.example.cleanup.Models;

public class CleanersModel {
    String cleaner_id, fname, lname, employee_nb, role, bio, address, email, phone,icon, score;

    public CleanersModel(String cleaner_id, String fname, String lname, String employee_nb, String role, String bio, String address, String email, String phone, String icon,String score) {
        this.cleaner_id = cleaner_id;
        this.fname = fname;
        this.lname = lname;
        this.employee_nb = employee_nb;
        this.role = role;
        this.bio = bio;
        this.address = address;
        this.email = email;
        this.phone = phone;
        this.icon = icon;
        this.score = score;
    }

    public String getScore() {
        return score;
    }

    public String getCleaner_id() {
        return cleaner_id;
    }

    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public String getEmployee_nb() {
        return employee_nb;
    }

    public String getRole() {
        return role;
    }

    public String getBio() {
        return bio;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getIcon() {
        return icon;
    }
}
