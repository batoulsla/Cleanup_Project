package com.example.cleanup.Models;

public class UsersModel {
    String id, name, role, phone ,email, address, employee_nb, products_ids,icon;

    public UsersModel(String id, String name, String role, String phone, String email, String address, String employee_nb, String products_ids, String icon) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.employee_nb = employee_nb;
        this.products_ids = products_ids;
        this.icon = icon;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getEmployee_nb() {
        return employee_nb;
    }

    public String getProducts_ids() {
        return products_ids;
    }

    public String getIcon() {
        return icon;
    }
}
