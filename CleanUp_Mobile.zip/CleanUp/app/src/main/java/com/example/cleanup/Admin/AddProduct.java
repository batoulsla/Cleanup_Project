package com.example.cleanup.Admin;

import static com.example.cleanup.Utilities.Config.IPADMIN;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.Adapters.AdminUsersAdapter;
import com.example.cleanup.Models.UsersModel;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AddProduct extends AppCompatClass {

    private TextInputEditText name;
    private MaterialButton btn_add;
    private RadioGroup radioGroup;
    private String type="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        setMethods("Products",""); // all methods are for products
    }

    @Override
    // Initialize views
    public void setInitialize() {
        super.setInitialize();
        radioGroup = findViewById(R.id.radio_group);
        name = findViewById(R.id.name_edit);
        btn_add = findViewById(R.id.btn_add);


    }

    @SuppressLint("NonConstantResourceId")
    @Override

    // Add click listener to the "Add" button
    public void setActions() {
        super.setActions();
        btn_add.setOnClickListener(v -> insertProduct());
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            switch (checkedId){
                case R.id.friendly:
                    type = "friendly";
                    break;
                case R.id.not_friendly:
                    type = "not friendly";
                    break;
            }
        });


    }

    // Method to insert a product into the database

    private void insertProduct(){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, IPADMIN + "insert_product.php", response -> {
            if(response.contains("success")){
                Toast.makeText(AddProduct.this, "Added Successfully", Toast.LENGTH_SHORT).show();
                name.setText("");

            }else { //if the query is not achieved
                Toast.makeText(AddProduct.this, response.trim(), Toast.LENGTH_SHORT).show();
            }


        }, error -> {
            Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show();
        }){

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("name",name.getText().toString());
                map.put("type",type);
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(AddProduct.this);
        requestQueue.add(stringRequest);
    }
}