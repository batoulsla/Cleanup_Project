


package com.example.cleanup.Utilities;

import android.app.Activity;
import android.os.Handler;
import android.view.View;
import android.widget.FrameLayout;

import com.example.cleanup.R;

public class LoadingLayout {

    public static void show(Activity activity){
        FrameLayout layout_loading = activity.findViewById(R.id.layout_loading);
        layout_loading.setVisibility(View.VISIBLE);
    }

    public static void hide(Activity activity){
        FrameLayout layout_loading = activity.findViewById(R.id.layout_loading);
        layout_loading.setVisibility(View.GONE);

    }
}
