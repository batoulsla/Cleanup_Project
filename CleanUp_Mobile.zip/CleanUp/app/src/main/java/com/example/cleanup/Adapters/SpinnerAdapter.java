package com.example.cleanup.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.cleanup.Models.SitesModel;
import com.example.cleanup.R;

import java.util.ArrayList;

public class SpinnerAdapter extends BaseAdapter {
    private final ArrayList<SitesModel> arrayList;
    private final Context context;
    
    // spinner that appears when the costumer wants to choose site(already added)
    // while booking

    public SpinnerAdapter(Context context, ArrayList<SitesModel> arrayList) {
        this.arrayList = arrayList;
        this.context=context;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        
        if (view == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.layout_spinner, parent, false);
        }
        TextView location = view.findViewById(R.id.location);
        location.setText(arrayList.get(position).getLocation());
        return view;
    }
}
