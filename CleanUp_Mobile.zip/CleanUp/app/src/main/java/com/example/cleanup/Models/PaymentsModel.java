package com.example.cleanup.Models;

public class PaymentsModel {
    String id, customer_id, customer_name, customer_icon,
    cleaner_id, cleaner_name, cleaner_icon, cleaner_role,
    amount, date,payment_method;

    public PaymentsModel(String id, String customer_id, String customer_name, String customer_icon, String cleaner_id, String cleaner_name, String cleaner_icon, String cleaner_role, String amount, String date, String payment_method) {
        this.id = id;
        this.customer_id = customer_id;
        this.customer_name = customer_name;
        this.customer_icon = customer_icon;
        this.cleaner_id = cleaner_id;
        this.cleaner_name = cleaner_name;
        this.cleaner_icon = cleaner_icon;
        this.cleaner_role = cleaner_role;
        this.amount = amount;
        this.date = date;
        this.payment_method = payment_method;
    }

    public String getId() {
        return id;
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public String getCustomer_icon() {
        return customer_icon;
    }

    public String getCleaner_id() {
        return cleaner_id;
    }

    public String getCleaner_name() {
        return cleaner_name;
    }

    public String getCleaner_icon() {
        return cleaner_icon;
    }

    public String getCleaner_role() {
        return cleaner_role;
    }

    public String getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getPayment_method() {
        return payment_method;
    }
}
