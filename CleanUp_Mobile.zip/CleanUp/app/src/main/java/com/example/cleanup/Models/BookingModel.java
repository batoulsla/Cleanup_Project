package com.example.cleanup.Models;

import java.util.ArrayList;

public class BookingModel {
    String id, date, time,service_id,service_name, service_price, customer_id,customer_name, customer_email, customer_icon,
            cleaner_id,cleaner_icon, cleaner_name, cleaner_email, status, offer_id, offer_price,offer_time, offer_description, offer_icon, site_id, site_location, site_area
            ,payment_id, payment_type, payment_amount, reject_cause;

    ArrayList<ServiceModel> arrayList;



    public BookingModel(String id, String date, String time, String customer_id, String customer_name, String customer_email, String customer_icon,
                        String cleaner_id, String cleaner_name, String cleaner_email,String cleaner_icon,
                        String status, String offer_id, String offer_price, String offer_time,
                        String offer_description, String offer_icon, String site_id,
                        String site_location, String site_area, String payment_id, String payment_type, String payment_amount,String reject_cause,ArrayList<ServiceModel> arrayList) {
        this.reject_cause = reject_cause;
        this.payment_amount = payment_amount;
        this.payment_id = payment_id;
        this.payment_type = payment_type;
        this.customer_icon = customer_icon;
        this.id = id;
        this.offer_icon = offer_icon;
        this.cleaner_icon = cleaner_icon;
        this.date = date;
        this.time = time;
        this.customer_id = customer_id;
        this.customer_name = customer_name;
        this.customer_email = customer_email;
        this.cleaner_id = cleaner_id;
        this.cleaner_name = cleaner_name;
        this.cleaner_email = cleaner_email;
        this.status = status;
        this.offer_id = offer_id;
        this.offer_price = offer_price;
        this.offer_time = offer_time;
        this.offer_description = offer_description;
        this.arrayList = arrayList;
        this.site_id = site_id;
        this.site_area = site_area;
        this.site_location = site_location;
    }

    public String getCustomer_icon() {
        return customer_icon;
    }

    public String getOffer_icon() {
        return offer_icon;
    }

    public String getSite_id() {
        return site_id;
    }

    public String getSite_location() {
        return site_location;
    }

    public String getSite_area() {
        return site_area;
    }

    public ArrayList<ServiceModel> getArrayList() {
        return arrayList;
    }

    public String getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getCleaner_icon() {
        return cleaner_icon;
    }

    public String getReject_cause() {
        return reject_cause;
    }

    public String getTime() {
        return time;
    }

    public String getService_id() {
        return service_id;
    }

    public String getService_name() {
        return service_name;
    }

    public String getService_price() {
        return service_price;
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public String getPayment_amount() {
        return payment_amount;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public String getCustomer_email() {
        return customer_email;
    }

    public String getCleaner_id() {
        return cleaner_id;
    }

    public String getCleaner_name() {
        return cleaner_name;
    }

    public String getCleaner_email() {
        return cleaner_email;
    }

    public String getStatus() {
        return status;
    }

    public String getOffer_id() {
        return offer_id;
    }

    public String getOffer_price() {
        return offer_price;
    }

    public String getOffer_time() {
        return offer_time;
    }

    public String getOffer_description() {
        return offer_description;
    }

    public String getPayment_id() {
        return payment_id;
    }

    public String getPayment_type() {
        return payment_type;
    }
}
