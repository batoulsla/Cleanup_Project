package com.example.cleanup.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.cleanup.R;

public class HelpAndSupport extends AppCompatActivity {
//help and support
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_and_support);
    }
}