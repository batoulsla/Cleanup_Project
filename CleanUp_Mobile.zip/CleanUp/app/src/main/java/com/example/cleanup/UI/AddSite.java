package com.example.cleanup.UI;

import static com.example.cleanup.Utilities.Config.IP;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.Models.SitesModel;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.example.cleanup.Utilities.SuperScript;
import com.example.cleanup.Utilities.UserData;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class AddSite extends AppCompatClass {
    private UserData userData;
    private TextInputEditText area, location, room, floor;
    private TextInputLayout layout_area;
    private MaterialButton btn_add, btn_continue;
    private String   type, offer_id;
    private double amount;
    private Spinner spinner;
    private SpinnerAdapter spinnerAdapter;
    private ArrayList<SitesModel> arrayList;

    private String site_id = "", cleaner_id="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_site);
        setMethods("Add Site", "");
    }

    @Override
    public void setActions() {
        super.setActions();
        btn_add.setOnClickListener(v -> add());
        getSites();
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(arrayList.get(position).getId().equals("0000")){
                    btn_continue.setVisibility(View.GONE);
                    site_id = "";
                }else {
                    btn_continue.setVisibility(View.VISIBLE);
                    site_id = arrayList.get(position).getId();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btn_continue.setOnClickListener(v -> goCleaners());
        layout_area.setSuffixText("m" + SuperScript.convert("2"));
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        userData = new UserData(AddSite.this);
        layout_area= findViewById(R.id.layout_area);
        area= findViewById(R.id.area_edit);
        location= findViewById(R.id.location_edit);
        room= findViewById(R.id.room_edit);
        floor= findViewById(R.id.floor_edit);
        btn_continue= findViewById(R.id.btn_continue);
        btn_add= findViewById(R.id.btn_add);
        spinner= findViewById(R.id.spinner);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null) { // if iam booking  from  companies or offers
            cleaner_id = bundle.getString("cleaner_id","");
            type = bundle.getString("type","");
            offer_id = bundle.getString("offer_id","");
            amount = bundle.getDouble("amount",0.0);
        }
    }

    private void add(){
        Random rand = new Random();
        int max=1000000,min=10000;
        int randomNum = rand.nextInt(max - min + 1) + min;
        site_id = ""+ randomNum;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, IP + "add_site.php", response -> {
            if(!response.toLowerCase(Locale.ROOT).contains("success")){
                Toast.makeText(AddSite.this, response.trim(), Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(AddSite.this, "New site add successfully", Toast.LENGTH_SHORT).show();
                floor.setText("");
                room.setText("");
                location.setText("");
                area.setText("");
                goCleaners();
            }
        }, error -> Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()){

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("room",room.getText().toString());
                map.put("floor",floor.getText().toString());
                map.put("location",location.getText().toString());
                map.put("area",area.getText().toString());
                map.put("user_id",userData.getId());
                map.put("site_id","" + site_id);
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(AddSite.this);
        requestQueue.add(stringRequest);
    }

    private void getSites(){
        arrayList = new ArrayList<>();
        arrayList.add(new SitesModel("0000","0000","Select site", "000","0","0","0"));
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_sites_where.php?user_id=" + userData.getId(), response -> {

            {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        String site_id = jSONObject.getString("site_id");
                        String site_location = jSONObject.getString("site_location");
                        String site_area = jSONObject.getString("site_area");
                        String floors_nb = jSONObject.getString("floors_nb");
                        String room_nb = jSONObject.getString("room_nb");
                        arrayList.add(new SitesModel(site_id, site_area,site_location, userData.getId(), room_nb, floors_nb,"0"));
                        i++;
                    }
                    spinnerAdapter = new com.example.cleanup.Adapters.SpinnerAdapter(AddSite.this, arrayList);
                    spinner.setAdapter(spinnerAdapter);
                }catch (Exception | Error ignored){}
            }

        }, error -> Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()){ };

        RequestQueue requestQueue = Volley.newRequestQueue(AddSite.this);
        requestQueue.add(stringRequest);
    }

    private void goCleaners(){
        Intent intent;
        if(cleaner_id.equals("")){
            intent = new Intent(AddSite.this, AllCleaners.class);
            intent.putExtra("site_id", site_id);
        }else{
            intent = new Intent(AddSite.this, Booking.class);
            intent.putExtra("cleaner_id", cleaner_id);
            intent.putExtra("site_id", site_id);
            intent.putExtra("type", type);
            intent.putExtra("offer_id", offer_id);
            intent.putExtra("amount", amount);
        }
        startActivity(intent);

    }
}