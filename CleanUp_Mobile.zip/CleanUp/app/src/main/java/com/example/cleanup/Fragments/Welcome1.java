package com.example.cleanup.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.cleanup.R;

public class Welcome1 extends Fragment {



    public Welcome1() {
        // Required empty public constructor
    }

    public static Welcome1 newInstance() {

        return new Welcome1();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v=  inflater.inflate(R.layout.fragment_welcome1, container, false);

        return v;
    }
}