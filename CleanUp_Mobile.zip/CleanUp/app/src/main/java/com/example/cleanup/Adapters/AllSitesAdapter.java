package com.example.cleanup.Adapters;

import static com.example.cleanup.Utilities.Config.IP;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.Models.SitesModel;
import com.example.cleanup.R;
import com.example.cleanup.UI.AllSites;
import com.example.cleanup.UI.SiteInfo;
import com.example.cleanup.Utilities.SuperScript;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AllSitesAdapter extends RecyclerView.Adapter<AllSitesAdapter.MyHolder> implements Filterable {
    private final ArrayList<SitesModel> list;
    private final ArrayList<SitesModel> listFull;
    private final Context context;

    public AllSitesAdapter(Context activity, ArrayList<SitesModel> list) {
        this.list = list;
        context = activity;
        listFull =new ArrayList<>(list);
    }
    // ViewHolder class
    public static class MyHolder extends RecyclerView.ViewHolder {
        private final TextView location, area, room, floor, delete_cause;
        private final MaterialCardView cardView;
        private final ShapeableImageView icon_delete;
        // Initialize views
        public MyHolder(View v) {
            super(v);
            room = v.findViewById(R.id.room);
            floor = v.findViewById(R.id.floor);
            location = v.findViewById(R.id.location);
            area = v.findViewById(R.id.area);
            icon_delete = v.findViewById(R.id.icon_delete);
            cardView = v.findViewById(R.id.cardView);
            delete_cause = v.findViewById(R.id.delete_cause);


        }
    }

    @NonNull
    @Override
    // Inflate the item layout
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_all_sites, parent, false);
        return new MyHolder(v);
    }

    @SuppressLint("SetTextI18n")
    @Override
    // Create and return a new instance of MyHolder
    public void onBindViewHolder(@NonNull final MyHolder holder, @SuppressLint("RecyclerView") final int position) {

        SitesModel currentItem = list.get(position); // Retrieve the current item from the data list
        // Set the values of the views in the holder with the corresponding data

        holder.floor.setText(currentItem.getFloors_nb().toUpperCase(Locale.ROOT));
        holder.room.setText(currentItem.getRoom_nb().toUpperCase(Locale.ROOT));
        holder.area.setText(currentItem.getArea().toUpperCase(Locale.ROOT) + " m" + SuperScript.convert("2") );
        holder.location.setText(currentItem.getLocation());
        holder.location.setSelected(true);
        // Set the state of the icon_delete ImageView based on the "used" value of the current item
        if (currentItem.getUsed().equals("0")) {
            holder.icon_delete.setEnabled(true);
            holder.icon_delete.setImageTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.black, null)));
            holder.delete_cause.setText("");
        } else {
            holder.icon_delete.setEnabled(false);
            holder.icon_delete.setImageTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.silver, null)));
            holder.delete_cause.setText("Site used, can't be deleted now");
        }


        // Set a click listener for the cardView
        holder.cardView.setOnClickListener(v -> {
            // Start the SiteInfo activity and pass the site_id as an extra
            Intent intent = new Intent(context, SiteInfo.class);
            intent.putExtra("site_id", list.get(position).getId());
            context.startActivity(intent);
        });
        holder.icon_delete.setOnClickListener(v -> {
            // Call the delete() method to delete the site with the corresponding site_id
           delete(list.get(position).getId());
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }



    @Override
    // Filter implementation
    public Filter getFilter() {
        return filter;
    }
    // filter android widgets
    private final Filter filter =new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<SitesModel> list1=new ArrayList<>();
            if(charSequence==null || charSequence.length()==0){
                list1.addAll(listFull);
            }
            else {
                String filterPattern=charSequence.toString().toLowerCase().trim();
                for (SitesModel item: listFull){
                    if(
                            item.getLocation().toLowerCase().contains(filterPattern)|
                                    item.getFloors_nb().toLowerCase().contains(filterPattern)|
                                    item.getArea().toLowerCase().contains(filterPattern)|
                                    item.getRoom_nb().toLowerCase().contains(filterPattern) ){
                        list1.add(item);
                    }
                }
            } // add the results to list 1 filtered ones
            FilterResults results=new FilterResults();
            results.values=list1;
            return results;
        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        @SuppressWarnings("unchecked")
        //to show this results
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            try {
                list.clear();
                list.addAll((ArrayList<SitesModel>)filterResults.values);
                notifyDataSetChanged();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };
//method to delete site
    void delete(String site_id){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete Site");
        builder.setMessage("Are you sure?");
        builder.setIcon(R.drawable.ic_delete);
        builder.setPositiveButton("Yes", (dialog, which) -> {
            StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "delete_site.php?id="+ site_id , response -> {
                Toast.makeText(context, response.trim(), Toast.LENGTH_SHORT).show(); //response trim removes any white spaces
                ((AllSites)context).getSites();
            }, error -> {
            });

            RequestQueue requestQueue = Volley.newRequestQueue(context);
            requestQueue.add(stringRequest);
        });
        builder.setNegativeButton("No" ,null); //dismiss the dialog without performing any further action when clicked.

        builder.show();
    }

}