package com.example.cleanup.UI;

import static com.example.cleanup.Utilities.Config.IP;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.Adapters.AllSitesAdapter;
import com.example.cleanup.Models.SitesModel;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.google.android.material.appbar.MaterialToolbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class AllSites extends AppCompatClass {
    private RecyclerView recyclerView;
    private ArrayList<SitesModel> arrayList;
    private AllSitesAdapter adapter;
    private MaterialToolbar toolbar;
    private SearchView searchView;
    private String user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_sites);
        setMethods("Sites", "");
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        recyclerView = findViewById(R.id.recyclerView);
        toolbar = findViewById(R.id.generalToolbar);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null){
            user_id = bundle.getString("user_id","");
        }
    }

    @Override
    public void setActions() {
        super.setActions();
        toolbar.inflateMenu(R.menu.menu_search);
        MenuItem item = toolbar.getMenu().findItem(R.id.item_search);
        searchView = (SearchView) item.getActionView();
        getSites();
    }
    
    public void getSites(){
        arrayList = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, IP + "select_sites_where.php?user_id=" + user_id, response -> {

            {
                int i = 0;
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = new JSONArray(jsonObject.getString("data"));
                    while (i < jsonArray.length()) {
                        JSONObject jSONObject = jsonArray.getJSONObject(i);
                        String site_id = jSONObject.getString("site_id");
                        String site_location = jSONObject.getString("site_location");
                        String site_area = jSONObject.getString("site_area");
                        String floors_nb = jSONObject.getString("floors_nb");
                        String room_nb = jSONObject.getString("room_nb");
                        String used = jSONObject.getString("used");
                        arrayList.add(new SitesModel(site_id, site_area,site_location, user_id, room_nb, floors_nb,used));
                        i++;
                    }

                    adapter = new AllSitesAdapter(AllSites.this, arrayList);
                    recyclerView.setAdapter(adapter);
                    searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                        @Override
                        public boolean onQueryTextSubmit(String query) {
                            return false;
                        }

                        @Override
                        public boolean onQueryTextChange(String newText) {
                            adapter.getFilter().filter(newText);
                            return true;
                        }
                    });
                }catch (Exception | Error ignored){}
            }

        }, error -> Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()){ };

        RequestQueue requestQueue = Volley.newRequestQueue(AllSites.this);
        requestQueue.add(stringRequest);
    }
}