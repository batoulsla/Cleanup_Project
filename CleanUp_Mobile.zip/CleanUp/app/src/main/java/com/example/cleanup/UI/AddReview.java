package com.example.cleanup.UI;

import static com.example.cleanup.Utilities.Config.IP;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.example.cleanup.Utilities.UserData;
import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AddReview extends AppCompatClass {
    private UserData userData;
    private EditText text;
    String user_id, cleaner_id, book_id;

    private MaterialButton btn_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_review);
        setMethods("Add review", "");
    }

    @Override
    public void setActions() {
        super.setActions();
        btn_add.setOnClickListener(v -> add());
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        userData = new UserData(AddReview.this);
        text= findViewById(R.id.text);
        btn_add= findViewById(R.id.btn_add);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null){
            cleaner_id = bundle.getString("cleaner_id", "");
            book_id = bundle.getString("book_id", "");
        }
        user_id = userData.getId();
    }

    private void add(){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, IP + "add_review.php", response -> {
            if(!response.toLowerCase(Locale.ROOT).contains("success")){
                Toast.makeText(AddReview.this, response.trim(), Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(AddReview.this, "New review add successfully", Toast.LENGTH_SHORT).show();
                finish();

            }
        }, error -> Toast.makeText(this, error.toString(), Toast.LENGTH_SHORT).show()){

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("text",text.getText().toString());
                map.put("cleaner_id",cleaner_id);
                map.put("book_id",book_id);
                map.put("user_id",userData.getId());
                map.put("date",getCurrentDate());
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(AddReview.this);
        requestQueue.add(stringRequest);
    }
    private String getCurrentDate(){
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return df.format(c);
    }
}