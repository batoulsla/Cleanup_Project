package com.example.cleanup.UI;

import static com.example.cleanup.Utilities.Config.IP;
import static com.example.cleanup.Utilities.GetImagePath.getRealPath;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.cleanup.FileUpload.ImageUploaderClass;
import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;
import com.example.cleanup.Utilities.LoadingLayout;
import com.example.cleanup.Utilities.UserData;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.HashMap;
import java.util.Map;

public class SignUp extends AppCompatClass {
    private MaterialToolbar toolbar;
    private TextView text_login;
    private UserData userData;
    private String user_role = "";
    private ActivityResultLauncher<Intent> activityResultLauncher;

    Uri uriImage = null;
    String nameOfImage="", typeOfImage="";
    private TextInputEditText fname,lname,email,phone,password,employee_nb;
    private TextInputLayout layout_fname,layout_lname, layout_employee;
    private MaterialButton btn_signup;

    private ShapeableImageView icon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        setMethods("","");

    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null){
            user_role = bundle.getString("type", "");
        }
        icon = findViewById(R.id.icon);
        toolbar = findViewById(R.id.generalToolbar);
        text_login = findViewById(R.id.text_login);
        fname = findViewById(R.id.fn_edit);
        lname = findViewById(R.id.ln_edit);
        email = findViewById(R.id.email_edit);
        phone = findViewById(R.id.phone_edit);
        password = findViewById(R.id.password_edit);
        btn_signup = findViewById(R.id.btn_signup);
        employee_nb = findViewById(R.id.employee_edit);
        layout_employee = findViewById(R.id.employee_layout);
        layout_lname = findViewById(R.id.ln_layout);
        layout_fname = findViewById(R.id.fn_layout);
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    public void setActions() {
        super.setActions();
        if(user_role.equals("company")){
            layout_fname.setHint("Name");
            layout_lname.setVisibility(View.GONE);
            lname.setText("-");
        }else {
            layout_employee.setVisibility(View.GONE);
            employee_nb.setText("0");
        }
        toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_close));
        text_login.setOnClickListener(v -> {
            Intent intent = new Intent(SignUp.this, LogIn.class);
            startActivity(intent);
        });
        btn_signup.setOnClickListener(v -> {
            if(uriImage != null){
                uploadImage();
                insertUser();
            }else {
                Toast.makeText(SignUp.this, "Choose icon", Toast.LENGTH_SHORT).show();
            }
        });
        icon.setOnClickListener(v -> checkPermission());
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        if (result.getData() != null) {
                            uriImage = result.getData().getData();
                            ContentResolver cr = this.getContentResolver();
                            typeOfImage = cr.getType(uriImage);

                        }
                        if (uriImage != null) {
                            Glide.with(this).load(uriImage).into(icon);
                            nameOfImage = "icon_"+System.currentTimeMillis()+"."+typeOfImage.replace("image/","");

                        }
                    }
                });
    }

    public static boolean checkResponseIfSuccess(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }

    private void insertUser(){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, IP + "signup.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(!response.trim().contains(",,")){
                    Toast.makeText(SignUp.this, response.trim(), Toast.LENGTH_SHORT).show();
                }else{
                    LoadingLayout.show(SignUp.this);
                    userData = new UserData(SignUp.this);
                    Toast.makeText(SignUp.this, "Success", Toast.LENGTH_SHORT).show();
                    String [] data = response.trim().split(",,");
                    userData.setUserData(data[0], data[1]);
                    Intent intent = new Intent(SignUp.this, MainActivity.class);
                    intent.putExtra("tab","4");
                    LoadingLayout.hide(SignUp.this);
                    startActivity(intent);
                    finish();
                }



            }
        }, error -> {

        }){

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("fname",fname.getText().toString());
                map.put("lname",lname.getText().toString());
                map.put("email",email.getText().toString());
                map.put("employee_nb",employee_nb.getText().toString());
                map.put("password",password.getText().toString());
                map.put("phone",phone.getText().toString());
                map.put("user_role",user_role);
                map.put("icon",nameOfImage);
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(SignUp.this);
        requestQueue.add(stringRequest);
    }
    
    
    //Settings to choose image from gallery
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && (grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
            openGallery();
        } else {
            Toast.makeText(SignUp.this, "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }
    public void openGallery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(SignUp.this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                activityResultLauncher.launch(intent);
            } else {
                ActivityCompat.requestPermissions(SignUp.this, new String[]{Manifest.permission.READ_MEDIA_IMAGES}, 100);
            }
        }else{
            if (ActivityCompat.checkSelfPermission(SignUp.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                activityResultLauncher.launch(intent);
            } else {
                ActivityCompat.requestPermissions(SignUp.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
            }
        }
    }



    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(SignUp.this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            }else{
                ActivityCompat.requestPermissions(SignUp.this, new String[]{Manifest.permission.READ_MEDIA_IMAGES}, 100);
            }
        }else{

            if (ActivityCompat.checkSelfPermission(SignUp.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            } else {
                ActivityCompat.requestPermissions(SignUp.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
            }
        }

    }

    private void uploadImage(){
        String filePath = getRealPath(this, uriImage);
        ImageUploaderClass.uploadImage(filePath, nameOfImage, "images/users", new ImageUploaderClass.onSuccessfulTask() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onFailed(String error) {

            }
        });
    }




}