package com.example.cleanup.UI;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import com.example.cleanup.R;
import com.example.cleanup.Utilities.AppCompatClass;

@SuppressLint("CustomSplashScreen")
public class SplashScreen extends AppCompatClass {
    private Intent intent;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        setMethods("", "");

        try {
            // Set flags to achieve a full-screen immersive experience
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } catch (Exception | Error ignored) {
            // Handle any exceptions or errors that occur while setting window flags
        }
    }

    @Override
    public void setInitialize() {
        super.setInitialize();
        sharedPreferences = getSharedPreferences("firstTime", MODE_PRIVATE);
    }

    @Override
    public void setActions() {
        super.setActions();

        // Check if it's the first time the app is launched
        if (sharedPreferences.getBoolean("firstTime", true)) {
            intent = new Intent(SplashScreen.this, Welcome.class);
        } else {
            intent = new Intent(SplashScreen.this, MainActivity.class);
        }

        // Create a new Handler and post a delayed runnable to start the desired activity
        new Handler().postDelayed(() -> {
            startActivity(intent);
            finish();
        }, 1000);
    }
}
