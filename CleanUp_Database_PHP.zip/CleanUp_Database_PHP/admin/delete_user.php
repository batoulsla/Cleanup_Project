<?php
include '../connection.php';
$id = $_GET['id'];
$sql=mysqli_query($connect,"Delete from reviews WHERE `UserID` = '$id'");
$sql=mysqli_query($connect,"Delete from booking WHERE `UserID` = '$id'");
$sql=mysqli_query($connect,"Delete from offers WHERE `o_cleaner_id` = '$id'");
$sql=mysqli_query($connect,"Delete from payments WHERE `UserID` = '$id'");
$sql=mysqli_query($connect,"Delete from payment_information WHERE `user_id` = '$id'");
$sql=mysqli_query($connect,"Delete from payment_information WHERE `user_id` = '$id'");
$sql=mysqli_query($connect,"Delete from services WHERE `s_cleaner_id` = '$id'");
$sql=mysqli_query($connect,"Delete from services WHERE `s_cleaner_id` = '$id'");
$sql=mysqli_query($connect,"Delete from sites WHERE `site_user_id` = '$id'");
$sql=mysqli_query($connect,"Delete from users WHERE `user_id` = '$id'");
$connect -> close();
?>
