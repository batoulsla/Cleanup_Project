<?php
include '../connection.php';
$sql="select * from payments ORDER BY `PaymentID` DESC";
		$res=mysqli_query($connect,$sql);
		$count=mysqli_num_rows($res);
		if($count>0){
			while($row=mysqli_fetch_assoc($res)){
				$cleaner_id = $row['CleanerID'];
				$user_id = $row['UserID'];
				$sql_user="SELECT * FROM `users` WHERE user_id = '$user_id' ";
				$res_user=mysqli_query($connect,$sql_user);
				$row_user=mysqli_fetch_assoc($res_user);
				$array_user = array('customer_info' => $row_user);
			
				$sql_cleaner="SELECT * FROM `users` WHERE user_id = '$cleaner_id' ";
				$res_cleaner=mysqli_query($connect,$sql_cleaner);
				$row2=mysqli_fetch_assoc($res_cleaner);
				$array_cleaner = array('cleaner_info' => $row2);
				$arr[]=$row + $array_user + $array_cleaner ;
				}
				echo json_encode(['status'=>'true','data'=>$arr,'result'=>'found']);
				}else{
					echo json_encode(['status'=>'true','data'=>[],'result'=>'not found']);
					}
				
$connect -> close();?>