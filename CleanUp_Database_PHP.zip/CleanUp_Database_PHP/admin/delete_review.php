<?php
include '../connection.php';
$id = $_GET['id'];
$sql="Delete from reviews WHERE `ReviewID` = '$id'";
		$res=mysqli_query($connect,$sql);
		if($res){
			echo "Deleted";
				}else{
					echo "Can't delete";
					}
$connect -> close();
