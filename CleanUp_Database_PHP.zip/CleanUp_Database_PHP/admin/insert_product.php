<?php
include_once "../connection.php";
$name = mysqli_real_escape_string($connect, $_POST['name']);
$type = mysqli_real_escape_string($connect, $_POST['type']);
if (!empty($name) && !empty($type)){
    $insert_query = mysqli_query($connect, "INSERT INTO `cleaning_products`(`p_name`,`p_clarification`) VALUES ('$name','$type')");
    if ($insert_query) {
        echo "success";
    } else {
        echo "Can't add";
    }
}else {
    echo "All input fields are required!";
}
$connect->close();
