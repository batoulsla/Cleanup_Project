<?php
include_once "../connection.php";
$name = mysqli_real_escape_string($connect, $_POST['name']);
    $insert_query = mysqli_query($connect, "INSERT INTO `attachments`(`FileName`) VALUES ('$name')");
    if ($insert_query) {
        echo "Image added";
    } else {
        echo "Can't add";
    }

$connect->close();
