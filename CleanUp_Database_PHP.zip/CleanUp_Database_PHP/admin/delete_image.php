<?php
include '../connection.php';
$name = $_GET['name'];
$dir =  "../images/main/";
$sql="Delete from attachments WHERE `FileName` = '$name'";
		$res=mysqli_query($connect,$sql);
		if($res){
			echo "Deleted";
			unlink($dir . $name);
				}else{
					echo "Can't delete";
					}
$connect -> close();
