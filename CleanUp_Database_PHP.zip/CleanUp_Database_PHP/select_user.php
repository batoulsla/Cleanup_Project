<?php


include 'connection.php';
$id = $_GET['id'];
$sql="select * from users WHERE `user_id` = '$id'";
		$res=mysqli_query($connect,$sql);
		$count=mysqli_num_rows($res);
		if($count>0){
			while($row=mysqli_fetch_assoc($res)){
				$sql2="select * from offers WHERE `o_cleaner_id` = '$id'";
		        $res2=mysqli_query($connect,$sql2);
				$count2=mysqli_num_rows($res2);
				$array_offer_count = array('offers_count' => $count2);
				$arr[]=$row + $array_offer_count;
				}
				
				echo json_encode(['status'=>'true','data'=>$arr,'result'=>'found']);
				}else{
					echo json_encode(['status'=>'true','data'=>[],'result'=>'not found']);
					}
				
$connect -> close();?>