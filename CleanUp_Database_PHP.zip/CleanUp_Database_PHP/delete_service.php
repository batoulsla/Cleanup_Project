<?php
include 'connection.php';
$id = $_GET['id'];
$sql="Delete from services WHERE `ServiceID` = '$id'";
		$res=mysqli_query($connect,$sql);
		if($res){
			echo "Deleted";
				}else{
					echo "Can't delete";
					}
$connect -> close();
