<?php
include_once "connection.php";
$name = mysqli_real_escape_string($connect, $_POST['name']);
$price = mysqli_real_escape_string($connect, $_POST['price']);
$user_id = mysqli_real_escape_string($connect, $_POST['user_id']);
if (!empty($name) && !empty($price) ) {
                $insert_query = mysqli_query($connect, "INSERT INTO services (ServiceName, ServicePrice, s_cleaner_id)
                                VALUES ('$name','$price', '$user_id')");
                if ($insert_query) {
                        echo "success";
                   
                } else {
                    echo "Something went wrong. Please try again!";
                }
            }
    
 else {
    echo "All input fields are required!";
}
$connect->close();
