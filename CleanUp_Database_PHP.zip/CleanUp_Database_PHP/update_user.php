<?php
include_once "connection.php";
$fname = mysqli_real_escape_string($connect, $_POST['fname']);
$lname = mysqli_real_escape_string($connect, $_POST['lname']);
$email = mysqli_real_escape_string($connect, $_POST['email']);
$phone = mysqli_real_escape_string($connect, $_POST['phone']);
$user_id = mysqli_real_escape_string($connect, $_POST['user_id']);
$password = mysqli_real_escape_string($connect, $_POST['password']);
$icon = mysqli_real_escape_string($connect, $_POST['icon']);
$employee_nb = mysqli_real_escape_string($connect, $_POST['employee_nb']);
$bio = mysqli_real_escape_string($connect, $_POST['bio']);
$address = mysqli_real_escape_string($connect, $_POST['address']);
$products_ids = mysqli_real_escape_string($connect, $_POST['products_ids']);



if (!empty($fname) && !empty($lname) && !empty($email) && !empty($password) && !empty($phone)) {
    $insert_query = mysqli_query($connect, "UPDATE users SET  `f_name` = '$fname', `l_name` ='$lname', `phone_nb`='$phone', `email` = '$email',
                 `password` = '$password',  `icon` = '$icon',`employee_nb` = '$employee_nb', `bio`='$bio', `address` = '$address', `products_ids` = '$products_ids' WHERE `user_id` = '$user_id'");
    if ($insert_query) {
        echo "Updated Successfully";
    } else {
        echo "Can't Update";
    }
} else {
    echo "All input fields are required!";
}
$connect->close();
