<?php
include 'connection.php';
$id = $_GET['id'];
$sql="Delete from booking WHERE `bookingID` = '$id'";
		$res=mysqli_query($connect,$sql);
		if($res){
			echo "Canceled";
				}else{
					echo "Can't cancel";
					}
$connect -> close();
