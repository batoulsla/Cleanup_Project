<?php
include 'connection.php';
$cleaner_id = $_GET['cleaner_id'];
$sql="select * from booking 
LEFT JOIN `users` ON(`booking`.`CleanerID` = `users`.`user_id`)
WHERE `booking`.`CleanerID` = '$cleaner_id' ORDER BY `booking`.`bookingID` DESC";
		$res=mysqli_query($connect,$sql);
		$count=mysqli_num_rows($res);
		if($count>0){
			while($row=mysqli_fetch_assoc($res)){
				$user_id = $row['UserID'];
				$offer_id = $row['book_offer_id'];
				$site_id = $row['book_site_id'];
				$payment_id = $row['payment_id'];
				$array_services = array();
				$services_id = explode(",",$row['ServiceID']);
				foreach ($services_id as $value) {
					$sql_service="SELECT * FROM `services` WHERE `ServiceID` = '$value' ";
				$res_service=mysqli_query($connect,$sql_service);
				$row_service=mysqli_fetch_assoc($res_service);
				array_push($array_services, $row_service);
				}
				$array_ser = array('services' => $array_services);
				
			
				$sql_cleaner="SELECT * FROM `users` WHERE user_id = '$user_id' ";
				$res_cleaner=mysqli_query($connect,$sql_cleaner);
				$row2=mysqli_fetch_assoc($res_cleaner);
				$array_cleaner = array('customer_info' => $row2);

				$sql_offer="SELECT * FROM `offers` WHERE offer_id = '$offer_id' ";
				$res_offer=mysqli_query($connect,$sql_offer);
				$row3=mysqli_fetch_assoc($res_offer);
				$array_offer = array('offer_info' => $row3);

				$sql_site="SELECT * FROM `sites` WHERE site_id = '$site_id' ";
				$res_site=mysqli_query($connect,$sql_site);
				$row4=mysqli_fetch_assoc($res_site);
				$array_site = array('site_info' => $row4);

				$sql_payemnt="SELECT * FROM `payments` WHERE PaymentID = '$payment_id' ";
				$res_payment=mysqli_query($connect,$sql_payemnt);
				$row_pay=mysqli_fetch_assoc($res_payment);
				$array_payment= array('payment_info' => $row_pay);

		         $arr[]=$row + $array_cleaner + $array_offer + $array_site + $array_ser + $array_payment;
			
				}
				
				echo json_encode(['status'=>'true','data'=>$arr,'result'=>'found']);
				}else{
					echo json_encode(['status'=>'true','data'=>[],'result'=>'not found']);
					}
				
$connect -> close();?>