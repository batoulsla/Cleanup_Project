<?php

$folder = $_POST["folder"];
if (!file_exists($folder)) {
mkdir($folder);}
$path=$folder."/".($_FILES["uploaded_file"]["name"]);
$r = move_uploaded_file($_FILES["uploaded_file"]["tmp_name"],$path);
if($r){
echo 'ok';
}
else{
echo 'Media not uploaded';
}
?>