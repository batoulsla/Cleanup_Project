<?php

include_once "connection.php";
$fname = mysqli_real_escape_string($connect, $_POST['fname']);
$lname = mysqli_real_escape_string($connect, $_POST['lname']);
$email = mysqli_real_escape_string($connect, $_POST['email']);
$phone = mysqli_real_escape_string($connect, $_POST['phone']);
$user_role = mysqli_real_escape_string($connect, $_POST['user_role']);
$password = mysqli_real_escape_string($connect, $_POST['password']);
$icon = mysqli_real_escape_string($connect, $_POST['icon']);
$employee_nb = mysqli_real_escape_string($connect, $_POST['employee_nb']);
    $date = new DateTime();
    $id =  $date->getTimestamp() ;
   

if (!empty($fname) && !empty($lname) && !empty($email) && !empty($password) && !empty($phone)) {

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $regx = "/^(?=.*[a-z])(?=.*\\d).{8,}$/i";
        $valid_password = preg_match($regx, $password);
        if(!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $password)) {
            $sql = mysqli_query($connect, "SELECT * FROM users WHERE email = '{$email}'");
            if (mysqli_num_rows($sql) > 0) {
                echo "$email - This email already exist!";
            } else {
                $encrypt_pass = md5($password);
                $insert_query = mysqli_query($connect, "INSERT INTO users (user_id, f_name, l_name, phone_nb, email, password, UserRole, icon,employee_nb)
                                VALUES ('$id','$fname', '$lname','$phone', '$email', '$encrypt_pass', '$user_role', '$icon','$employee_nb')");
                if ($insert_query) {
                    $select_sql2 = mysqli_query($connect, "SELECT * FROM users WHERE email = '{$email}'");
                    if (mysqli_num_rows($select_sql2) > 0) {
                        $result = mysqli_fetch_assoc($select_sql2);
                        echo $id.",,".$user_role;
                     
                    } else {
                        echo "This email address not Exist!";
                    }
                } else {
                    echo "Something went wrong. Please try again!";
                }
            }
        } else {
            echo "Error password! must have at least 1 uppercase character and greater than 8";
        }
    } else {
        echo "$email is not a valid email!";
    }

    
} else {
    echo "All input fields are required!";
}
$connect->close();
