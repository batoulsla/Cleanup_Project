<?php
include_once "connection.php";
$payment_type = mysqli_real_escape_string($connect, $_POST['type']);
$cvc = mysqli_real_escape_string($connect, $_POST['cvc']);
$name = mysqli_real_escape_string($connect, $_POST['name']);
$yy = mysqli_real_escape_string($connect, $_POST['yy']);
$mm = mysqli_real_escape_string($connect, $_POST['mm']);
$number = mysqli_real_escape_string($connect, $_POST['number']);
$user_id = mysqli_real_escape_string($connect, $_POST['user_id']);
$date =  $yy."-".$mm;
if (!empty($cvc) && !empty($name) && !empty($yy) && !empty($mm) && !empty($number) ) {
                $insert_query = mysqli_query($connect, "INSERT INTO `payment_information`(`user_id`, `card_nb`, `expiration_date`, `CVV`, `payment_type`,`holder_name`) VALUES ('$user_id','$number','$date','$cvc', '$payment_type','$name')");
                if ($insert_query) {
                        echo "Payment card added";
                   
                } else {
                    echo "Something went wrong. Please try again!";
                }
            }
    
 else {
    echo "All input fields are required!";
}
$connect->close();
