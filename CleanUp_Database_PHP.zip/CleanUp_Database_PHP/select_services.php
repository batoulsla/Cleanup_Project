<?php


include 'connection.php';
$sql="select * from services";
		$res=mysqli_query($connect,$sql);
		$count=mysqli_num_rows($res);
		if($count>0){
			while($row=mysqli_fetch_assoc($res)){
			
				$arr[]=$row;
				}
				
				echo json_encode(['status'=>'true','data'=>$arr,'result'=>'found']);
				}else{
					echo json_encode(['status'=>'true','data'=>[],'result'=>'not found']);
					}
				
$connect -> close();?>