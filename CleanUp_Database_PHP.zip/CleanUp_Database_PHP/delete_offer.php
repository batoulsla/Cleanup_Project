<?php
include 'connection.php';
$id = $_GET['id'];
$icon = $_GET['icon'];
$dir =  "images/offers/";
$sql="Delete from offers WHERE `offer_id` = '$id'";
		$res=mysqli_query($connect,$sql);
		if($res){
			unlink($dir . $icon);
			echo "Deleted";
				}else{
					echo "Can't delete";
					}
$connect -> close();
