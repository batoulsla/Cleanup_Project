<?php
include_once "connection.php";
$book_id = mysqli_real_escape_string($connect, $_GET['book_id']);
$status = mysqli_real_escape_string($connect, $_GET['status']);
$cause = mysqli_real_escape_string($connect, $_GET['cause']);

    $insert_query = mysqli_query($connect, "UPDATE booking SET  `book_status` = '$status',`rejected_cause` = '$cause' WHERE `bookingID` = '$book_id'");
    if ($insert_query) {
        echo "Updated Successfully";
    } else {
        echo "Can't Update";
    }

$connect->close();
