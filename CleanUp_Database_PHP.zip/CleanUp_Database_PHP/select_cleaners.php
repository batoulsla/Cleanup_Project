<?php


include 'connection.php';
$limit = $_GET['limit'];
$sql="select * from users WHERE `UserRole` = 'individual' OR `UserRole` = 'company' LIMIT $limit";
		$res=mysqli_query($connect,$sql);
		$count=mysqli_num_rows($res);
		if($count>0){
			while($row=mysqli_fetch_assoc($res)){
				$products = $row['products_ids'];
				$ids = array_filter(explode(",", $products));
				$friendly_count = 0;
				foreach($ids as $items) {
					$sql2="select * from cleaning_products WHERE `p_id` = '$items'";
					$res2=mysqli_query($connect,$sql2);
			
					while($row2=mysqli_fetch_assoc($res2)){
						if($row2['p_clarification'] == "friendly"){
							$friendly_count++;
						}
					}
					
				}
				
				
				if(count($ids) == 0){
					$row['score'] = "";
				}else{
					$percentage = $friendly_count  / count($ids) * 100;
					switch ($percentage) {
						case $percentage == 100:
							$row['score'] = "a";
						  break;
	
						  case $percentage >= 90 && $percentage <= 99:
							$row['score'] = "b";
						  break;
	
						  case $percentage >= 80 && $percentage <= 89:
							$row['score'] = "c";
						  break;
	
						  case $percentage >= 70 && $percentage <= 79:
							$row['score'] = "d";
						  break;
	
						  case $percentage >= 60 && $percentage <= 69:
							$row['score'] = "e";
						  break;
	
						  case $percentage <= 59:
							$row['score'] = "f";
						  break;
					  }
				}
				$arr[]=$row;
				}
				
				echo json_encode(['status'=>'true','data'=>$arr,'result'=>'found']);
				}else{
					echo json_encode(['status'=>'true','data'=>[],'result'=>'not found']);
					}
				
$connect -> close();?>