<?php


include 'connection.php';
$limit = $_GET['limit'];
$sql="select * from offers
ORDER BY `offers`.`offer_id` DESC LIMIT $limit ";
		$res=mysqli_query($connect,$sql);
		$count=mysqli_num_rows($res);
		if($count>0){
			while($row=mysqli_fetch_assoc($res)){
				$user_id = $row['o_cleaner_id'];
				$sql_cleaner="SELECT * FROM `users` WHERE user_id = '$user_id' ";
				$res_cleaner=mysqli_query($connect,$sql_cleaner);
				$row2=mysqli_fetch_assoc($res_cleaner);
				$array_cleaner = array('cleaner_info' => $row2);
				$arr[]=$row + $array_cleaner;
				}
				
				echo json_encode(['status'=>'true','data'=>$arr,'result'=>'found']);
				}else{
					echo json_encode(['status'=>'true','data'=>[],'result'=>'not found']);
					}
				
$connect -> close();?>