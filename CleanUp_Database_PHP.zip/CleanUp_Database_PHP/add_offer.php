<?php
include_once "connection.php";
$description = mysqli_real_escape_string($connect, $_POST['description']);
$date = mysqli_real_escape_string($connect, $_POST['date']);
$icon = mysqli_real_escape_string($connect, $_POST['icon']);
$price = mysqli_real_escape_string($connect, $_POST['price']);
$user_id = mysqli_real_escape_string($connect, $_POST['user_id']);
if (!empty($description) && !empty($price) && !empty($date)) {
                $insert_query = mysqli_query($connect, "INSERT INTO offers (`o_cleaner_id`, `description`, `icon` ,`price`, `time`)
                                VALUES ('$user_id','$description','$icon','$price', '$date')");
                if ($insert_query) {
                        echo "success";
                   
                } else {
                    echo "Something went wrong. Please try again!";
                }
            }
    
 else {
    echo "All input fields are required!";
}
$connect->close();
