<?php
include 'connection.php';
$user_id = $_GET['user_id'];
$sql="select * from payment_information WHERE `user_id` = '$user_id' ORDER BY `payment_id` DESC";
		$res=mysqli_query($connect,$sql);
		$count=mysqli_num_rows($res);
		if($count>0){
			while($row=mysqli_fetch_assoc($res)){
				$payment_id = $row['payment_id'];
				$sql2="select * from payments WHERE `PaymentInfoID` = '$payment_id' ";
				$res2=mysqli_query($connect,$sql2);
		         $count2=mysqli_num_rows($res2);
				 if($count2 > 0){
					$row['used'] = "1";
				 }else{
					$row['used'] = "0";
				 }
				 $arr[]=$row;
				}
				
				echo json_encode(['status'=>'true','data'=>$arr,'result'=>'found']);
				}else{
					echo json_encode(['status'=>'true','data'=>[],'result'=>'not found']);
					}
				
$connect -> close();?>