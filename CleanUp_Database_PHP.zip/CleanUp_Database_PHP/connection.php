<?php
ini_set('display_errors', 1);
$servername = "localhost";
$username = "root";
$password = "";
$database = "clean_up";
$connect = new mysqli($servername, $username, $password,$database);
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
} 
$f='SET NAMES utf8mb4';
$sSQL= 'SET CHARACTER SET utf8mb4'; 
mysqli_query($connect,$sSQL) 
or die ('Can\'t charset in DataBase'); 
mysqli_query($connect,$f) 
or die ('Can\'t charset in DataBase'); 
?>