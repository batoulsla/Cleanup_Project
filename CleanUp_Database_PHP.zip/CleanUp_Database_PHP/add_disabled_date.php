<?php
include_once "connection.php";
$date = mysqli_real_escape_string($connect, $_POST['date']);
$user_id = mysqli_real_escape_string($connect, $_POST['user_id']);
                $sql=mysqli_query($connect, "UPDATE `users` SET `disabled_date`='$date' WHERE `user_id` = '$user_id'");
                if ($sql) {
                        echo "success";
                   
                } else {
                    echo "Something went wrong. Please try again!";
                }

$connect->close();
