<?php
include_once "connection.php";
$room = mysqli_real_escape_string($connect, $_POST['room']);
$floor = mysqli_real_escape_string($connect, $_POST['floor']);
$location = mysqli_real_escape_string($connect, $_POST['location']);
$area = mysqli_real_escape_string($connect, $_POST['area']);
$user_id = mysqli_real_escape_string($connect, $_POST['user_id']);
$site_id =  $_POST['site_id'];
if (!empty($area) && !empty($location) && !empty($room)&& !empty($floor)) {
                $insert_query = mysqli_query($connect, "INSERT INTO sites (`site_id`,`site_area`, `site_location`, `site_user_id`,`floors_nb`,`room_nb`)
                                VALUES ('$site_id','$area','$location', '$user_id','$floor','$room')");
                if ($insert_query) {
                        echo "success";
                   
                } else {
                    echo "Something went wrong. Please try again!";
                }
            }
    
 else {
    echo "All input fields are required!";
}
$connect->close();
