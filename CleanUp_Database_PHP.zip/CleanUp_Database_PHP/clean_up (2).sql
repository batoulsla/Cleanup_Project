-- phpMyAdmin SQL Dump
-- version 5.3.0-dev+20220428.abf60329bb
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2023 at 05:33 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clean_up`
--

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `AttachmentID` int(11) NOT NULL,
  `FileName` varchar(255) DEFAULT NULL,
  `ImagePath` varchar(255) DEFAULT NULL,
  `ImageData` blob DEFAULT NULL,
  `OwnerID` int(11) DEFAULT NULL,
  `UploadDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`AttachmentID`, `FileName`, `ImagePath`, `ImageData`, `OwnerID`, `UploadDate`) VALUES
(7, 'icon_1684328265312.jpeg', NULL, NULL, NULL, NULL),
(8, 'icon_1684328267051.jpeg', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingID` int(11) NOT NULL,
  `bookingDate` date DEFAULT NULL,
  `bookingTime` time DEFAULT NULL,
  `ServiceID` varchar(255) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `CleanerID` int(11) DEFAULT NULL,
  `book_status` enum('Rejected','Pending','Accepted','Completed') NOT NULL,
  `book_site_id` int(11) DEFAULT NULL,
  `book_offer_id` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `rejected_cause` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingID`, `bookingDate`, `bookingTime`, `ServiceID`, `UserID`, `CleanerID`, `book_status`, `book_site_id`, `book_offer_id`, `payment_id`, `rejected_cause`) VALUES
(47, '2023-05-24', '03:09:00', '10382', 102, 1, 'Completed', 1024, NULL, 582122, ''),
(48, '2023-05-19', '04:32:00', '10380,10367', 101, 1, 'Pending', 1025, NULL, 589898, '');

-- --------------------------------------------------------

--
-- Table structure for table `cleaning_products`
--

CREATE TABLE `cleaning_products` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_clarification` enum('friendly','not friendly') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cleaning_products`
--

INSERT INTO `cleaning_products` (`p_id`, `p_name`, `p_clarification`) VALUES
(1, 'Baking soda', 'friendly'),
(2, 'Vinegar', 'friendly'),
(3, 'Lemon juice', 'friendly'),
(4, 'Castile soap', 'friendly'),
(5, 'Borax', 'not friendly'),
(6, 'Bleach', 'not friendly'),
(7, 'Ammonia', 'not friendly'),
(8, 'Hydrogen peroxide', 'friendly'),
(9, 'Citric acid', 'friendly'),
(10, 'Essential oils', 'friendly'),
(11, 'Dish soap', 'not friendly'),
(12, 'Oven cleaner', 'not friendly'),
(13, 'Drain cleaner', 'not friendly'),
(14, 'Degreaser', 'not friendly');

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `offer_id` int(11) NOT NULL,
  `o_cleaner_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `time` date NOT NULL,
  `used` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`offer_id`, `o_cleaner_id`, `description`, `icon`, `price`, `time`, `used`) VALUES
(31, 1, 'Offer from company Company Four', 'icon24.png', '144.32', '2023-05-17', 0),
(32, 11, 'Offer from company Company Eleven', 'icon25.png', '801.87', '2023-05-17', 0),
(33, 5, 'Offer from company Company Five', 'icon26.png', '582.54', '2023-05-17', 0),
(34, 11, 'Offer from company Company One', 'icon27.png', '287.38', '2023-05-17', 0),
(35, 10, 'Offer from company Company Ten', 'icon28.png', '169.91', '2023-05-17', 0),
(36, 3, 'Offer from company Company Three', 'icon29.png', '795.51', '2023-05-17', 0),
(37, 8, 'Offer from company Company Eight', 'icon30.png', '167.58', '2023-05-17', 0),
(38, 6, 'Offer from company Company Six', 'icon31.png', '769.26', '2023-05-17', 0),
(39, 7, 'Offer from company Company Seven', 'icon32.png', '373.21', '2023-05-17', 0),
(40, 2, 'Offer from company Company Two', 'icon33.png', '441.15', '2023-05-17', 0),
(41, 9, 'Offer from company Company Nine', 'icon34.png', '825.17', '2023-05-17', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `CleanerID` int(11) DEFAULT NULL,
  `AmountPaid` decimal(8,2) DEFAULT NULL,
  `PaymentMethod` enum('cash','credit card','debit card','paypal') DEFAULT NULL,
  `PaymentInfoID` int(11) DEFAULT NULL,
  `PaymentDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `UserID`, `CleanerID`, `AmountPaid`, `PaymentMethod`, `PaymentInfoID`, `PaymentDate`) VALUES
(1, 104, 2, '2000.00', 'cash', 111, '2023-05-09'),
(582122, 101, 2, '66.42', 'cash', NULL, '2023-05-18'),
(589898, 101, 1, '105.93', 'paypal', 131, '2023-05-18');

-- --------------------------------------------------------

--
-- Table structure for table `payment_information`
--

CREATE TABLE `payment_information` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_nb` varchar(50) NOT NULL,
  `expiration_date` varchar(10) NOT NULL,
  `CVV` varchar(10) NOT NULL,
  `payment_type` enum('credit card','debit card','paypal') DEFAULT NULL,
  `holder_name` varchar(255) NOT NULL,
  `used` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment_information`
--

INSERT INTO `payment_information` (`payment_id`, `user_id`, `card_nb`, `expiration_date`, `CVV`, `payment_type`, `holder_name`, `used`) VALUES
(96, 107, '6985-6743-2761-1573', '9/26', 'ee9', 'credit card', 'User292 Userlastname43', 0),
(97, 105, '6114-8413-4725-6383', '9/30', 'a2f', 'credit card', 'User725 Userlastname75', 0),
(98, 103, '7820-2811-7592-1531', '2/25', '7fa', 'credit card', 'User361 Userlastname27', 0),
(99, 101, '2550-7401-1356-1578', '3/29', 'c00', 'credit card', 'User978 Userlastname429', 0),
(100, 103, '7818-2463-5860-2915', '6/27', '915', 'credit card', 'User132 Userlastname931', 0),
(101, 104, '5469-7400-1596-2778', '10/25', '859', 'credit card', 'User943 Userlastname512', 0),
(102, 109, '1965-4163-4923-2127', '4/24', 'd24', 'credit card', 'User989 Userlastname561', 0),
(103, 111, '5566-1208-6338-9070', '9/29', '645', 'credit card', 'User741 Userlastname562', 0),
(104, 108, '3241-5359-7072-9284', '7/24', '6a3', 'credit card', 'User222 Userlastname337', 0),
(105, 101, '1660-3865-4343-9121', '5/25', 'fe4', 'credit card', 'User218 Userlastname452', 0),
(106, 108, '7067-5982-7706-1589', '2/25', '585', 'credit card', 'User400 Userlastname887', 0),
(107, 103, '5511-8295-5944-3837', '12/28', '0c0', 'credit card', 'User376 Userlastname800', 0),
(111, 103, '1098-4727-1342-9530', '8/25', '151', 'debit card', 'User850 Userlastname629', 0),
(112, 108, '1665-6353-7771-9801', '8/24', 'b24', 'debit card', 'User550 Userlastname5', 0),
(113, 105, '8784-2778-4538-4357', '9/25', '85f', 'debit card', 'User544 Userlastname233', 0),
(114, 107, '9723-3212-3892-8822', '5/25', '01e', 'debit card', 'User933 Userlastname560', 0),
(115, 112, '3856-6305-9957-2874', '1/28', 'bc8', 'debit card', 'User525 Userlastname334', 0),
(116, 102, '5197-1468-8750-2350', '2/26', 'fba', 'debit card', 'User906 Userlastname299', 0),
(117, 110, '9803-6104-9108-8231', '4/24', 'b43', 'debit card', 'User890 Userlastname821', 0),
(118, 106, '7229-2528-7952-4179', '6/24', 'b5c', 'debit card', 'User314 Userlastname849', 0),
(119, 104, '9627-9022-6230-3087', '5/26', '16e', 'debit card', 'User210 Userlastname32', 0),
(120, 107, '5982-2610-3102-6682', '6/26', '4ce', 'debit card', 'User688 Userlastname727', 0),
(121, 107, '7096-7050-3963-6664', '2/30', '368', 'debit card', 'User610 Userlastname846', 0),
(122, 105, '5085-1685-1169-8788', '4/29', 'b59', 'debit card', 'User623 Userlastname175', 0),
(126, 101, '7382-5887-6289-3786', '10/30', '9a5', 'paypal', 'User106 Userlastname675', 0),
(127, 101, '3324-2099-8524-8324', '7/25', 'a64', 'paypal', 'User599 Userlastname578', 0),
(128, 102, '7579-4392-7222-3936', '7/29', '195', 'paypal', 'User415 Userlastname971', 0),
(129, 108, '2146-8325-7188-9968', '12/27', '561', 'paypal', 'User597 Userlastname128', 0),
(130, 111, '8715-7691-2309-5472', '1/29', '8bb', 'paypal', 'User781 Userlastname85', 0),
(131, 101, '2285-5295-9618-4212', '11/26', 'f19', 'paypal', 'User39 Userlastname92', 0),
(132, 105, '5020-2804-6958-7381', '7/28', 'dfb', 'paypal', 'User327 Userlastname632', 0),
(133, 103, '9961-5007-3150-8728', '7/25', '4af', 'paypal', 'User163 Userlastname358', 0),
(134, 104, '4838-3099-8981-7612', '1/29', '7f3', 'paypal', 'User744 Userlastname921', 0),
(135, 105, '1854-4255-5715-5809', '2/30', '741', 'paypal', 'User258 Userlastname716', 0),
(136, 110, '8948-9984-4077-7433', '7/27', '89f', 'paypal', 'User934 Userlastname629', 0),
(137, 105, '8522-2316-3011-7107', '9/27', '050', 'paypal', 'User878 Userlastname221', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `ReviewID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `CleanerID` int(11) DEFAULT NULL,
  `ReviewText` text DEFAULT NULL,
  `r_booking_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`ReviewID`, `UserID`, `CleanerID`, `ReviewText`, `r_booking_id`, `date`) VALUES
(4, 101, 1, 'hiiii', 47, '2023-05-18');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `ServiceID` int(11) NOT NULL,
  `ServiceName` varchar(50) DEFAULT NULL,
  `ServicePrice` decimal(8,2) DEFAULT NULL,
  `s_cleaner_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`ServiceID`, `ServiceName`, `ServicePrice`, `s_cleaner_id`) VALUES
(10318, 'Regular cleaning', '57.76', 30),
(10319, 'Regular cleaning', '35.14', 28),
(10320, 'Regular cleaning', '71.35', 26),
(10321, 'Regular cleaning', '96.03', 28),
(10322, 'Regular cleaning', '95.81', 28),
(10323, 'Regular cleaning', '30.77', 25),
(10324, 'Regular cleaning', '49.02', 24),
(10325, 'Regular cleaning', '31.03', 25),
(10326, 'Regular cleaning', '95.45', 26),
(10327, 'Regular cleaning', '76.28', 26),
(10333, 'Deep cleaning', '5.45', 24),
(10334, 'Deep cleaning', '26.85', 24),
(10335, 'Deep cleaning', '10.02', 25),
(10336, 'Deep cleaning', '51.22', 26),
(10337, 'Deep cleaning', '94.59', 27),
(10338, 'Deep cleaning', '30.33', 25),
(10339, 'Deep cleaning', '12.09', 26),
(10340, 'Deep cleaning', '28.42', 23),
(10341, 'Deep cleaning', '27.29', 22),
(10342, 'Deep cleaning', '21.70', 29),
(10348, 'Tenancy cleaning', '56.90', 29),
(10349, 'Tenancy cleaning', '59.31', 30),
(10350, 'Tenancy cleaning', '26.42', 24),
(10351, 'Tenancy cleaning', '75.24', 28),
(10352, 'Tenancy cleaning', '78.01', 30),
(10353, 'Tenancy cleaning', '97.59', 29),
(10354, 'Tenancy cleaning', '64.69', 23),
(10355, 'Tenancy cleaning', '33.47', 27),
(10356, 'Tenancy cleaning', '82.96', 21),
(10357, 'Tenancy cleaning', '34.34', 27),
(10363, 'Regular cleaning', '49.67', 6),
(10364, 'Regular cleaning', '29.88', 5),
(10365, 'Regular cleaning', '65.20', 3),
(10366, 'Regular cleaning', '24.09', 2),
(10367, 'Regular cleaning', '82.65', 1),
(10368, 'Regular cleaning', '72.11', 6),
(10369, 'Regular cleaning', '50.92', 5),
(10370, 'Regular cleaning', '0.86', 10),
(10371, 'Regular cleaning', '34.55', 6),
(10372, 'Regular cleaning', '98.86', 8),
(10378, 'Deep cleaning', '77.69', 10),
(10379, 'Deep cleaning', '71.82', 6),
(10380, 'Deep cleaning', '23.28', 1),
(10381, 'Deep cleaning', '24.23', 11),
(10382, 'Deep cleaning', '66.42', 2),
(10383, 'Deep cleaning', '18.60', 8),
(10384, 'Deep cleaning', '56.79', 6),
(10385, 'Deep cleaning', '76.11', 5),
(10386, 'Deep cleaning', '25.11', 10),
(10387, 'Deep cleaning', '53.29', 3),
(10393, 'Tenancy cleaning', '59.77', 11),
(10394, 'Tenancy cleaning', '92.10', 6),
(10395, 'Tenancy cleaning', '86.59', 4),
(10396, 'Tenancy cleaning', '73.93', 7),
(10397, 'Tenancy cleaning', '98.19', 9),
(10398, 'Tenancy cleaning', '6.91', 3),
(10399, 'Tenancy cleaning', '67.40', 3),
(10400, 'Tenancy cleaning', '8.18', 3),
(10401, 'Tenancy cleaning', '40.13', 9),
(10402, 'Tenancy cleaning', '75.82', 6);

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE `sites` (
  `site_id` int(11) NOT NULL,
  `site_location` varchar(255) NOT NULL,
  `site_area` int(4) NOT NULL,
  `site_user_id` int(11) NOT NULL,
  `room_nb` int(3) NOT NULL,
  `floors_nb` int(2) NOT NULL,
  `used` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sites`
--

INSERT INTO `sites` (`site_id`, `site_location`, `site_area`, `site_user_id`, `room_nb`, `floors_nb`, `used`) VALUES
(1000, '123 Main St', 150, 101, 4, 2, 0),
(1001, '456 High St', 200, 101, 3, 1, 0),
(1002, '789 Elm St', 100, 102, 2, 1, 0),
(1003, '321 Oak St', 250, 102, 5, 3, 0),
(1004, '654 Pine St', 175, 103, 4, 2, 0),
(1005, '987 Cedar St', 225, 103, 3, 1, 0),
(1006, '246 Maple Ave', 125, 104, 2, 1, 0),
(1007, '135 Birch Ave', 275, 104, 5, 3, 0),
(1008, '864 Walnut Dr', 200, 105, 4, 2, 0),
(1009, '753 Oak Dr', 150, 105, 3, 1, 0),
(1010, '642 Maple Dr', 300, 106, 6, 3, 0),
(1011, '951 Pine Dr', 250, 106, 5, 2, 0),
(1012, '258 Cedar Blvd', 175, 107, 4, 1, 0),
(1013, '357 Elm Blvd', 225, 107, 3, 1, 0),
(1014, '456 Oak Blvd', 125, 108, 2, 1, 0),
(1015, '789 Maple St', 275, 108, 5, 3, 0),
(1016, '123 Pine St', 200, 109, 4, 2, 0),
(1017, '456 Cedar St', 150, 109, 3, 1, 0),
(1018, '789 Elm St', 300, 110, 6, 3, 0),
(1019, '321 Oak St', 250, 110, 5, 2, 0),
(1020, '654 Pine St', 175, 111, 4, 1, 0),
(1021, '987 Cedar St', 225, 111, 3, 1, 0),
(1022, '246 Maple Ave', 125, 112, 2, 1, 0),
(1023, '135 Birch Ave', 275, 112, 5, 3, 0),
(1024, '864 Walnut Dr', 200, 101, 4, 2, 0),
(1025, '753 Oak Dr', 150, 101, 3, 1, 0),
(1026, '642 Maple Dr', 300, 102, 6, 3, 0),
(1027, '951 Pine Dr', 250, 102, 5, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_nb` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `UserRole` enum('customer','company','individual','admin') DEFAULT NULL,
  `f_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `l_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `bio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `employee_nb` int(3) NOT NULL,
  `disabled_date` varchar(255) NOT NULL,
  `products_ids` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `score` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`, `phone_nb`, `address`, `icon`, `UserRole`, `f_name`, `l_name`, `bio`, `employee_nb`, `disabled_date`, `products_ids`, `score`) VALUES
(1, 'company1@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-1234', '123 Main St, Anytown, USA', 'icon1.png', 'company', 'Company', '-', 'We are a company.', 100, ',  2023-5-26 17:44, 2023-5-26 4:50', '5,6,7,13', ''),
(2, 'company2@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-5678', '456 Elm St, Anytown, USA', 'icon2.png', 'company', 'Company', 'Two', 'We are another company.', 50, '', '5,1,4,7,8', ''),
(3, 'company3@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-9012', '789 Oak St, Anytown, USA', 'icon3.png', 'company', 'Company', 'Three', 'We are a third company.', 200, '', '1,2', ''),
(4, 'company4@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-3456', '234 Maple St, Anytown, USA', 'icon4.png', 'company', 'Company', 'Four', 'We are a fourth company.', 75, '', '', ''),
(5, 'company5@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-7890', '567 Pine St, Anytown, USA', 'icon5.png', 'company', 'Company', 'Five', 'We are a fifth company.', 150, '', '', ''),
(6, 'company6@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-2345', '890 Cedar St, Anytown, USA', 'icon6.png', 'company', 'Company', 'Six', 'We are a sixth company.', 25, '', '', ''),
(7, 'company7@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-6789', '123 Oak St, Anytown, USA', 'icon7.png', 'company', 'Company', 'Seven', 'We are a seventh company.', 300, '', '', ''),
(8, 'company8@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-0123', '456 Maple St, Anytown, USA', 'icon8.png', 'company', 'Company', 'Eight', 'We are an eighth company.', 50, '', '', ''),
(9, 'company9@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-4567', '789 Pine St, Anytown, USA', 'icon9.png', 'company', 'Company', 'Nine', 'We are a ninth company.', 100, '', '', ''),
(10, 'company10@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-8901', '234 Cedar St, Anytown, USA', 'icon10.png', 'company', 'Company', 'Ten', 'We are a tenth company.', 200, '', '', ''),
(11, 'company11@example.com', 'password11', '555-2345', '567 Oak St, Anytown, USA', 'icon11.png', 'company', 'Company', 'Eleven', 'We are an eleventh company.', 75, '', '', ''),
(21, 'individual1@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-1234', '123 Main St, Anytown, USA', 'icon13.png', 'individual', 'Individual', 'One', 'I am an individual.', 0, '', '', ''),
(22, 'individual2@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-5678', '456 Elm St, Anytown, USA', 'icon14.png', 'individual', 'Individual', 'Two', 'I am another individual.', 0, '', '', ''),
(23, 'individual3@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-9012', '789 Oak St, Anytown, USA', 'icon15.png', 'individual', 'Individual', 'Three', 'I am a third individual.', 0, '', '', ''),
(24, 'individual4@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-3456', '234 Maple St, Anytown, USA', 'icon16.png', 'individual', 'Individual', 'Four', 'I am a fourth individual.', 0, '', '', ''),
(25, 'individual5@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-7890', '567 Pine St, Anytown, USA', 'icon17.png', 'individual', 'Individual', 'Five', 'I am a fifth individual.', 0, '', '', ''),
(26, 'individual6@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-2345', '890 Cedar St, Anytown, USA', 'icon18.png', 'individual', 'Individual', 'Six', 'I am a sixth individual.', 0, '', '', ''),
(27, 'individual7@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-6789', '123 Oak St, Anytown, USA', 'icon19.png', 'individual', 'Individual', 'Seven', 'I am a seventh individual.', 0, '', '', ''),
(28, 'individual8@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-0123', '456 Maple St, Anytown, USA', 'icon20.png', 'individual', 'Individual', 'Eight', 'I am an eighth individual.', 0, '', '', ''),
(29, 'individual9@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-4567', '789 Pine St, Anytown, USA', 'icon21.png', 'individual', 'Individual', 'Nine', 'I am a ninth individual.', 0, '', '', ''),
(30, 'individual10@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-8901', '234 Cedar St, Anytown, USA', 'icon22.png', 'individual', 'Individual', 'Ten', 'I am a tenth individual.', 0, '', '', ''),
(31, 'individual11@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '555-2345', '567 Oak St, Anytown, USA', 'icon23.png', 'individual', 'Individual', 'Eleven', 'I am an eleventh individual.', 0, '', '', ''),
(101, 'customer1@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '123 Main St, Anytown USA', 'icon35.png', 'customer', 'John', 'Doe', 'I am a customer', 0, '', '', ''),
(102, 'customer2@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '456 Oak St, Anytown USA', 'icon36.png', 'customer', 'Jane', 'Smith', 'I am also a customer', 0, '', '', ''),
(103, 'customer3@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '789 Elm St, Anytown USA', 'icon37.png', 'customer', 'Bob', 'Johnson', 'I am yet another customer', 0, '', '', ''),
(104, 'customer4@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '321 Birch St, Anytown USA', 'icon38.png', 'customer', 'Alice', 'Lee', 'I am a different customer', 0, '', '', ''),
(105, 'customer5@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '654 Pine St, Anytown USA', 'icon39.png', 'customer', 'David', 'Wang', 'I am a customer too', 0, '', '', ''),
(106, 'customer6@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '987 Cedar St, Anytown USA', 'icon40.png', 'customer', 'Mary', 'Nguyen', 'I am yet another customer', 0, '', '', ''),
(107, 'customer7@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '246 Maple St, Anytown USA', 'icon41.png', 'customer', 'Chris', 'Davis', 'I am a customer as well', 0, '', '', ''),
(108, 'customer8@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '369 Walnut St, Anytown USA', 'icon42.png', 'customer', 'Kelly', 'Garcia', 'I am another customer', 0, '', '', ''),
(109, 'customer9@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '582 Pineapple St, Anytown USA', 'icon43.png', 'customer', 'Steven', 'Martinez', 'I am a customer too', 0, '', '', ''),
(110, 'customer10@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '741 Mango St, Anytown USA', 'icon44.png', 'customer', 'Melissa', 'Clark', 'I am a customer also', 0, '', '', ''),
(111, 'customer11@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '852 Banana St, Anytown USA', 'icon45.png', 'customer', 'Brian', 'Lopez', 'I am a different customer', 0, '', '', ''),
(112, 'customer12@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '1234567890', '963 Apple St, Anytown USA', 'icon46.png', 'customer', 'Sarah', 'Hernandez', 'I am yet another customer', 0, '', '', ''),
(12345678, 'admin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '+96170707070', '', 'adminstrator.png', 'admin', 'CleanUp', '', '', 0, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`AttachmentID`),
  ADD KEY `owner_id` (`OwnerID`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingID`),
  ADD KEY `serviceID` (`ServiceID`),
  ADD KEY `user_id` (`UserID`),
  ADD KEY `cleaner_id` (`CleanerID`),
  ADD KEY `book_site_id` (`book_site_id`),
  ADD KEY `book_offer_id` (`book_offer_id`),
  ADD KEY `payment_id` (`payment_id`);

--
-- Indexes for table `cleaning_products`
--
ALTER TABLE `cleaning_products`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`offer_id`),
  ADD KEY `CleanerID` (`o_cleaner_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CleanerID` (`CleanerID`),
  ADD KEY `PaymentInfoID` (`PaymentInfoID`);

--
-- Indexes for table `payment_information`
--
ALTER TABLE `payment_information`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_id_2` (`user_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`ReviewID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CleanerID` (`CleanerID`),
  ADD KEY `r_booking_id` (`r_booking_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`ServiceID`),
  ADD KEY `s_cleaner_id` (`s_cleaner_id`);

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`site_id`),
  ADD KEY `site_user_id` (`site_user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `AttachmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `cleaning_products`
--
ALTER TABLE `cleaning_products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `offer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `payment_information`
--
ALTER TABLE `payment_information`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `ReviewID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `ServiceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10403;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attachments`
--
ALTER TABLE `attachments`
  ADD CONSTRAINT `owner_id` FOREIGN KEY (`OwnerID`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `book_offer_fk` FOREIGN KEY (`book_offer_id`) REFERENCES `offers` (`offer_id`),
  ADD CONSTRAINT `cleaner_id` FOREIGN KEY (`CleanerID`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_id_fk` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`PaymentID`),
  ADD CONSTRAINT `site_fk` FOREIGN KEY (`book_site_id`) REFERENCES `sites` (`site_id`),
  ADD CONSTRAINT `user_id` FOREIGN KEY (`UserID`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `offers`
--
ALTER TABLE `offers`
  ADD CONSTRAINT `offers_ibfk_1` FOREIGN KEY (`o_cleaner_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `cl_id_fk` FOREIGN KEY (`CleanerID`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `pay_ino_fk` FOREIGN KEY (`PaymentInfoID`) REFERENCES `payment_information` (`payment_id`),
  ADD CONSTRAINT `user_id_fk` FOREIGN KEY (`UserID`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `payment_information`
--
ALTER TABLE `payment_information`
  ADD CONSTRAINT `user_id_fk_pay` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `r_book_fk` FOREIGN KEY (`r_booking_id`) REFERENCES `booking` (`bookingID`),
  ADD CONSTRAINT `r_cle_fk` FOREIGN KEY (`CleanerID`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `r_user_fk` FOREIGN KEY (`UserID`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `ser_cle_id_fk` FOREIGN KEY (`s_cleaner_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `sites`
--
ALTER TABLE `sites`
  ADD CONSTRAINT `site_user_if_fk` FOREIGN KEY (`site_user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;



