<?php 

    include_once "connection.php";
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $password = mysqli_real_escape_string($connect, $_POST['password']);
    if(!empty($email) && !empty($password)){
        $sql = mysqli_query($connect, "SELECT * FROM users WHERE email = '{$email}'");
        if(mysqli_num_rows($sql) > 0){
            $row = mysqli_fetch_assoc($sql);
            $user_pass = md5($password);
            $enc_pass = $row['password'];
            $user_role = $row['UserRole'];
            $user_id = $row['user_id'];
            if($user_pass === $enc_pass){
                echo $user_id.",,".$user_role;
               
            }else{
                echo "Email or Password is Incorrect!";
            }
        }else{
            echo "$email - This email not Exist!";
        }
    }else{
        echo "All input fields are required!";
    }
    $connect->close();
?>