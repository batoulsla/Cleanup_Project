<?php

include_once "connection.php";
$date = mysqli_real_escape_string($connect, $_POST['date']);
$time = mysqli_real_escape_string($connect, $_POST['time']);
$user_id = mysqli_real_escape_string($connect, $_POST['user_id']);
$cleaner_id = mysqli_real_escape_string($connect, $_POST['cleaner_id']);
$site_id = mysqli_real_escape_string($connect, $_POST['site_id']);
$offer_id = mysqli_real_escape_string($connect, $_POST['offer_id']);
$services_ids = mysqli_real_escape_string($connect, $_POST['services_ids']);
$payment_date = mysqli_real_escape_string($connect, $_POST['payment_date']);
$amount = mysqli_real_escape_string($connect, $_POST['amount']);
$payment_type = mysqli_real_escape_string($connect, $_POST['payment_type']);
$payment_info_id = mysqli_real_escape_string($connect, $_POST['payment_info_id']);
$payment_id = mysqli_real_escape_string($connect, $_POST['payment_id']);
if ($offer_id == "") {
    $insert_query = "INSERT INTO booking (`bookingDate`, `bookingTime`, `ServiceID`, `UserID`, `CleanerID`, `book_status`, `book_site_id`, `book_offer_id`,`payment_id`)
    VALUES ('$date','$time', '$services_ids','$user_id', '$cleaner_id', 'Pending', '$site_id', null,'$payment_id')";
} else {
    $insert_query =  "INSERT INTO booking (`bookingDate`, `bookingTime`, `ServiceID`, `UserID`, `CleanerID`, `book_status`, `book_site_id`, `book_offer_id`,`payment_id`)
                                VALUES ('$date','$time', '$services_ids','$user_id', '$cleaner_id', 'Pending', '$site_id', '$offer_id','$payment_id')";
}
if ($payment_info_id == "") {
    $sql_payment = "INSERT INTO `payments`( `PaymentID`,`UserID`, `CleanerID`, `AmountPaid`, `PaymentMethod`, `PaymentInfoID`, `PaymentDate`) VALUES ('$payment_id','$user_id','$cleaner_id','$amount','$payment_type',null,'$payment_date')";

}else{
    $sql_payment = "INSERT INTO `payments`( `PaymentID`,`UserID`, `CleanerID`, `AmountPaid`, `PaymentMethod`, `PaymentInfoID`, `PaymentDate`) VALUES ('$payment_id','$user_id','$cleaner_id','$amount','$payment_type','$payment_info_id','$payment_date')";

}
$insert_payment = mysqli_query($connect, $sql_payment);
$insert_book = mysqli_query($connect, $insert_query);
if ($insert_payment) {
        echo "Request sent";
    
} else {
    echo "something error!!";
}
$connect->close();
