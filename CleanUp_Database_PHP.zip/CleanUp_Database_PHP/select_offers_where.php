<?php
include 'connection.php';
$user_id = $_GET['user_id'];
$sql="select * from offers WHERE `o_cleaner_id` = '$user_id' ORDER BY offer_id DESC";
		$res=mysqli_query($connect,$sql);
		$count=mysqli_num_rows($res);
		if($count>0){
			while($row=mysqli_fetch_assoc($res)){
				$offer_id = $row['offer_id'];
				$sql2="select * from booking WHERE `book_offer_id` = '$offer_id' ";
				$res2=mysqli_query($connect,$sql2);
		         $count2=mysqli_num_rows($res2);
				 if($count2 > 0){
					$row['used'] = "1";
				 }else{
					$row['used'] = "0";
				 }
				$arr[]=$row;
				}
				
				echo json_encode(['status'=>'true','data'=>$arr,'result'=>'found']);
				}else{
					echo json_encode(['status'=>'true','data'=>[],'result'=>'not found']);
					}
				
$connect -> close();?>