<?php
include_once "connection.php";
$text = mysqli_real_escape_string($connect, $_POST['text']);
$user_id = mysqli_real_escape_string($connect, $_POST['user_id']);
$cleaner_id = mysqli_real_escape_string($connect, $_POST['cleaner_id']);
$book_id = mysqli_real_escape_string($connect, $_POST['book_id']);
$date = mysqli_real_escape_string($connect, $_POST['date']);
if (!empty($text) ) {
                $insert_query = mysqli_query($connect, "INSERT INTO `reviews`(`UserID`, `CleanerID`, `ReviewText`, `r_booking_id`,`date`) 
                VALUES ('$user_id','$cleaner_id','$text','$book_id','$date')");
                if ($insert_query) {
                        echo "success";
                   
                } else {
                    echo "Something went wrong. Please try again!";
                }
            }
    
 else {
    echo "Enter your review";
}
$connect->close();
