<?php
include 'connection.php';
$id = $_GET['id'];
$sql="Delete from sites WHERE `site_id` = '$id'";
		$res=mysqli_query($connect,$sql);
		if($res){
			echo "Deleted";
				}else{
					echo "Can't cancel";
					}
$connect -> close();
